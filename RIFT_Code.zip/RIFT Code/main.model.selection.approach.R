rm(list=ls())
library(mixtools)
library(mclust)
setwd("~/Documents/Clustering research")
source("main_bottomup_hierarchical.R")
source("main_topdown_Marron.R")
source("SimulComparision.R")
source("Model.selection.approach.R")

# First example


d = 10
k = 4
n_clust = sample(c(25,50), size = k, replace = TRUE)
mu = rep(0,d)
sds = 4* rep(1,d)
min.dist = 3
K = 100
modelNames = NULL
set.seed(7)
n = sum(n_clust)
sample_no = c()
for(clust in 1:k){
  sample_no = c(sample_no, rep(clust,n_clust[clust])) 
}

Simple = rep(0,K)
Simple_L2 = rep(0,K)
AIC = rep(0,K)
BIC = rep(0,K)

found = 0
while(found == 0){
  mus = mvrnorm(n=4, mu, Sigma = diag(sds))
  distance.means = dist(mus)
  if(min(distance.means) > min.dist){
    found = 1
  }
}


for(i in 1:K){
  
  which.comp = sample(sample_no,size=n)
  data = mvrnorm(n, mu = rep(0,d), Sigma=diag(rep(1,d)))
  data = t(sapply(c(1:n), function(i){return(data[i,] + mus[which.comp[i],])}) )
  #data <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
  train.x = data[1:floor(n/2),]
  test.x = data[(floor(n/2)+1):n,]
  
  Cluster_number = Model.selection.approach(train.x, test.x, alpha, modelNames)  
  
  Simple[i] = Cluster_number$simple
  Simple_L2[i] = Cluster_number$simple_L2
  AIC[i] = Cluster_number$Min_AIC
  BIC[i] = Cluster_number$Min_BIC
  
  print(i)
}
table(Simple)
table(Simple_L2)
table(AIC)
table(BIC)

# Second example

d = 2
k = 4
delta = 10
set.seed(7)
n_clust = rep(100,k)
K = 100
alpha = 0.05
arr = "Square"

d = 20
k = 4
delta = 80
set.seed(7)
arr = "Tetra"


if(arr == "Square"){
  mus = rbind(c(0, 0, rep(0,(d - 2))), 
              c(0, delta, rep(0,(d - 2))),
              c(delta, 0, rep(0,(d - 2))),
              c(delta, delta, rep(0,(d - 2))))
}else if(arr == "Tetra"){
  mus = rbind(c(0, 0, 0, rep(0,(d - 3))), 
              c(0, delta, delta, rep(0,(d - 3))),
              c(delta, delta, 0, rep(0,(d - 3))),
              c(delta, 0, delta, rep(0,(d - 3))))
}else{
  mus = mvrnorm(n = k, rep(0,d), Sigma = diag(rep(1,d)))
}

n = sum(n_clust)
sample_no = c()
for(clust in 1:k){
  sample_no = c(sample_no, rep(clust,n_clust[clust])) 
}
Simple = rep(0,K)
Simple_L2 = rep(0,K)
AIC = rep(0,K)
BIC = rep(0,K)

for(i in 1:K){
  
  #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
  which.comp = sample(sample_no,size=n)
  
  
  data = mvrnorm(n, mu = rep(0,d), Sigma=diag(rep(1,d)))
  for(comp in 1:k){
    idx = which(which.comp == comp)
    data[idx,] = data[idx,] + matrix(rep(mus[comp,], length(idx)), 
                                     nrow = length(idx), byrow = T)
  }
  train.x = data[1:floor(n/2),]
  test.x = data[(floor(n/2)+1):n,]
  modelNames = "VVV"
  
  Cluster_number = Model.selection.approach(train.x, test.x, alpha, modelNames)  
  
  Simple[i] = Cluster_number$simple
  Simple_L2[i] = Cluster_number$simple_L2
  AIC[i] = Cluster_number$Min_AIC
  BIC[i] = Cluster_number$Min_BIC
  
  print(i)
}
table(Simple)
table(Simple_L2)
table(AIC)
table(BIC)

# Third example

d = 30
k = 10
set.seed(7)
n_clust = rep(150,k)
K = 100
alpha = 0.05

zeros = rep(0,d/5)
ones = rep(1,d/5)

mus = 500*rbind(c(ones, zeros, zeros, zeros, zeros),
            c( zeros, ones, zeros, zeros, zeros),
            c( zeros, zeros, ones, zeros, zeros),
            c( zeros, zeros,  zeros, ones, zeros),
            c( zeros, zeros, zeros, zeros, ones),
            c(- ones, zeros, zeros, zeros, zeros),
            c( zeros, - ones, zeros, zeros, zeros),
            c( zeros, zeros, - ones, zeros, zeros),
            c( zeros, zeros,  zeros, - ones, zeros),
            c( zeros, zeros, zeros, zeros, - ones))

sigmasq = c(0.001, 0.04, 0.16)

n = sum(n_clust)
sample_no = c()
for(clust in 1:k){
  sample_no = c(sample_no, rep(clust,n_clust[clust])) 
}

Simple = matrix(0, nrow = K, ncol = length(sigmasq))
Simple_L2 = matrix(0, nrow = K, ncol = length(sigmasq))
AIC = matrix(0, nrow = K, ncol = length(sigmasq))
BIC = matrix(0, nrow = K, ncol = length(sigmasq))

for(i in 1:K){
  
  #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
  which.comp = sample(sample_no,size=n)
  
  for(j in 1:length(sigmasq)){
    
    data = mvrnorm(n, mu = rep(0,d), Sigma = sigmasq[j]*diag(rep(1,d)))
    for(comp in 1:k){
      idx = which(which.comp == comp)
      data[idx,] = data[idx,] + matrix(rep(mus[comp,], length(idx)), 
                                       nrow = length(idx), byrow = T)
    }
    train.x = data[1:floor(n/2),]
    test.x = data[(floor(n/2)+1):n,]
    modelNames = "VVV"
    
    Cluster_number = Model.selection.approach(train.x, test.x, alpha, modelNames)  
    
    Simple[i,j] = Cluster_number$simple
    Simple_L2[i,j] = Cluster_number$simple_L2
    AIC[i,j] = Cluster_number$Min_AIC
    BIC[i,j] = Cluster_number$Min_BIC
  }
  
  print(i)
}

for(j in 1:length(sigmasq)){
  print(table(Simple[,j]))
  print(table(Simple_L2[,j]))
  print(table(AIC[,j]))
  print(table(BIC[,j]))
}

#Visualize the data
viz_data = as.data.frame(data)
viz_data$class = which.comp
pca_sim = princomp(viz_data[,1:30])$scores[,1:2]
plot(pca_sim, t='n')
text(pca_sim, labels = viz_data$class, col = viz_data$class)
#text(pca_sim, labels = viz_data$class, col = colors[viz_data$class])

# Plots for proposal presentation

SRIFT = c(rep(3,32), rep(4,68))
AIC = c(rep(3,46), rep(4,54))
BIC = c(rep(1,1), rep(2,41), rep(3, 58))
L2 = c(rep(1,60), rep(2, 22), rep(3,11), rep(4,7))
df2 = data.frame(SRIFT, AIC, BIC, L2)
colnames(df2) = c("S-RIFT (KL)", "AIC", "BIC", "S-RIFT (L2)")
df3 = gather(df2, algo, clusts)
df4 = df3
df4$clusts = as.character(df4$clusts)
df4$clusts[which(df3$clusts >=6)] = "Greater than 5"

plot = ggplot(data=df4, aes(x=clusts, fill=algo)) +
  geom_bar(stat="count", position=position_dodge())+
  scale_fill_brewer(palette="Paired")+
  theme_minimal()+labs( x = "No. of clusters", y = "No. of simulations", fill = "Algorithm\n")

plot = ggplot(data=df4, aes(x=algo, fill=clusts)) +
  geom_bar(stat="count")+
  scale_fill_brewer(palette="Paired", drop=FALSE)+
  theme_minimal()+labs( x = "Algorithm", y = "No. of simulations", fill = "No. of clusters\n") +
  scale_x_discrete(drop=FALSE)

pdf("SRIFT_plot_v2.pdf", width = 5, height = 3)
plot
dev.off()
