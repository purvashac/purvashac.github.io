rm(list=ls())
library(mixtools)
library(mclust)
setwd("~/Documents/Clustering research")
source("main_bottomup_hierarchical.R")
source("main_topdown_Marron.R")
source("SimulComparision.R")


# Signal in one direction

K = 100
#n = seq(from = 100, to = 1000, by = 50)
n = 100
d = 1000
sds = c(rep(10,10),rep(1,(d - 10)))
a = c(0, 10, 20)

pvalue_simple = matrix(0, nrow = K, ncol = length(a))
pvalue_simple_median =  matrix(0, nrow = K, ncol = length(a))
pvalue_Mardia =  matrix(0, nrow = K, ncol = length(a))
#pvalue_NN =  matrix(0, nrow = K, ncol = length(a))
#pvalue_NN_KS =  matrix(0, nrow = K, ncol = length(a))
pvalue_Marron =  matrix(0, nrow = K, ncol = length(a))

Power_simple = rep(0, length(a))
Power_simple_median = rep(0, length(a))
Power_Mardia = rep(0, length(a))
#Power_NN = rep(0, length(a))
#Power_NN_KS = rep(0, length(a))
Power_Marron = rep(0, length(a))



for(i in 1:length(a)){
  mu = c(a[i], rep(0,(d - 1)))
  Power.tests = Finding.Power.tests(n, mu, d, sds, alpha = 0.05, K, symmetry = F)
  Power_simple[i] = mean(Power.tests$reject_simple)
  Power_simple_median[i] = mean(Power.tests$reject_simple_median)
  Power_Mardia[i] = mean(Power.tests$reject_Mardia)
  #Power_NN[i] = mean(Power.tests$reject_NN)
  #Power_NN_KS[i] = mean(Power.tests$reject_NN_KS)
  Power_Marron[i] = mean(Power.tests$reject_Marron)
  
  pvalue_simple[,i] = Power.tests$pvalue_simple
  pvalue_simple_median[,i] = Power.tests$pvalue_simple_median
  pvalue_Mardia[,i] = Power.tests$pvalue_Mardia
  #pvalue_NN[,i] = Power.tests$pvalue_NN
  #pvalue_NN_KS[,i] = Power.tests$pvalue_NN_KS
  pvalue_Marron[,i] = Power.tests$pvalue_Marron
  
  print(i)
}


Power = data.frame(n = n, Simple = Power_simple, Simple_median = Power_simple_median,
                   Mardia = Power_Mardia, NN = Power_NN, NN_KS = Power_NN_KS, Marron = Power_Marron)
plot = ggplot(data = Power, aes(x = n))+
  geom_point(aes(y = n),
             colour = 'red', size = 3)

plot1 <- ggplot(Power, aes(x = log(Power$n))) + 
  ggtitle("Comparing Clustering Techniques with n varying")+
  xlab("Log n") + ylab("Power")+
  geom_line(aes(y = Power$Simple, colour = "Simple Test")) + 
  geom_line(aes(y = Simple_median, colour = "Simple Test with Median")) +
  geom_line(aes(y = Mardia, colour = "Mardia's Kurtosis Test")) +
  geom_line(aes(y = NN, colour = "Zhou's NN Test")) +
  geom_line(aes(y = NN_KS, colour = "Zhou's NN Test with KS")) +
  geom_line(aes(y = Marron, colour = "LHNM Test"))

pdf("MarronS1D.pdf", width = 8, height = 5)
plot1
dev.off()

# Signal in one direction

K = 100
#n = seq(from = 100, to = 1000, by = 50)
n = 100
d = 1000
sds = c(100, rep(1,(d - 1)))
a = c(0, 0.4, 0.6)

pvalue_simple2 = matrix(0, nrow = K, ncol = length(a))
pvalue_simple_median2 =  matrix(0, nrow = K, ncol = length(a))
pvalue_Mardia2 =  matrix(0, nrow = K, ncol = length(a))
#pvalue_NN2 =  matrix(0, nrow = K, ncol = length(a))
#pvalue_NN_KS2 =  matrix(0, nrow = K, ncol = length(a))
pvalue_Marron2 =  matrix(0, nrow = K, ncol = length(a))

Power_simple2 = rep(0, length(a))
Power_simple_median2 = rep(0, length(a))
Power_Mardia2 = rep(0, length(a))
#Power_NN2 = rep(0, length(a))
#Power_NN_KS2 = rep(0, length(a))
Power_Marron2 = rep(0, length(a))


for(i in 2:length(a)){
  mu = rep(a[i], d)
  Power.tests = Finding.Power.tests(n, mu, d, sds, alpha = 0.05, K, symmetry = F)
  Power_simple2[i] = mean(Power.tests$reject_simple)
  Power_simple_median2[i] = mean(Power.tests$reject_simple_median)
  Power_Mardia2[i] = mean(Power.tests$reject_Mardia)
  #Power_NN2[i] = mean(Power.tests$reject_NN)
  #Power_NN_KS2[i] = mean(Power.tests$reject_NN_KS)
  Power_Marron2[i] = mean(Power.tests$reject_Marron)
  
  pvalue_simple2[,i] = Power.tests$pvalue_simple
  pvalue_simple_median2[,i] = Power.tests$pvalue_simple_median
  pvalue_Mardia2[,i] = Power.tests$pvalue_Mardia
  #pvalue_NN2[,i] = Power.tests$pvalue_NN
  #pvalue_NN_KS2[,i] = Power.tests$pvalue_NN_KS
  pvalue_Marron2[,i] = Power.tests$pvalue_Marron
  
  print(i)
}


Power = data.frame(n = n, Simple = Power_simple, Simple_median = Power_simple_median,
                   Mardia = Power_Mardia, NN = Power_NN, NN_KS = Power_NN_KS, Marron = Power_Marron)
plot = ggplot(data = Power, aes(x = n))+
  geom_point(aes(y = n),
             colour = 'red', size = 3)

plot2 <- ggplot(Power, aes(x = log(Power$n))) + 
  ggtitle("Comparing Clustering Techniques with n varying")+
  xlab("Log n") + ylab("Power")+
  geom_line(aes(y = Power$Simple, colour = "Simple Test")) + 
  geom_line(aes(y = Simple_median, colour = "Simple Test with Median")) +
  geom_line(aes(y = Mardia, colour = "Mardia's Kurtosis Test")) +
  geom_line(aes(y = NN, colour = "Zhou's NN Test")) +
  geom_line(aes(y = NN_KS, colour = "Zhou's NN Test with KS")) +
  geom_line(aes(y = Marron, colour = "LHNM Test"))

pdf("MarronallD.pdf", width = 8, height = 5)
plot2
dev.off()
