library(sigclust)

model.logdensity.compute.one <- function(x, modeli, G = 1, truncated = F, diagonal = T){
  
  classlogdensity = rep(0,G)
  if(G == 1){
    logdensity = logdensitynormal(x,t(modeli$parameters$mean[,1]), 
                                  modeli$parameters$variance$sigma[,,1], diagonal)
  }else{
    logdensity = logdensitynormal(x,t(modeli$parameters$mean[,1]), 
                                  modeli$parameters$variance$sigma[,,1], diagonal)
    for(g in 2:G){
      classlogdensity[g] = logdensitynormal(x,t(modeli$parameters$mean[,g]), 
                                            modeli$parameters$variance$sigma[,,g], diagonal)
      logdensity = logxpy(logdensity, classlogdensity[g])
    }
  }
  return(logdensity)
}

model.logdensity.compute <- function(datax = train.x, modeli, G = 1, truncated = F, diagonal = T){
  
 modellogdensity = apply(datax, 1, function(x){
      return( model.logdensity.compute.one(x, modeli, G, truncated, diagonal))})
 return(modellogdensity)
}

Model.selection.approach <- function(train.x, test.x, alpha = 0.05, modelNames = NULL, diagonal = T){
  
  d = ncol(train.x)
  n = nrow(test.x)
  Kn = floor(sqrt(n))
  model = array(list(), Kn)
  t = 1
  log_likelihood = matrix(-10^{100}, nrow = n, ncol = Kn)
  number_rv = 5000*d
  theYs = matrix(rt(number_rv, t), nrow = 5000, ncol = d) 
  log_likelihood_Ys = matrix(-10^{100}, nrow = 5000, ncol = Kn)
  #if(modelNames == "EEE" || modelNames == "VVV"){diagonal = FALSE}
  model[[1]] = tryCatch(densityMclust(data = train.x, G = 1, modelNames),
                        error = function(err) {
                          
                          # error handler picks up where error was generated
                          print(paste("MY_ERROR:  ",err))
                          return(NA)
                          
                        })
  if(is.na(model[[1]])){ return(list(error = TRUE)) }
  diagonal = F
  if(model[[1]]$modelName %in% c("EII","VII","EEI","VEI","EVI","VVI")){diagonal = T}
  log_likelihood[,1] = model.logdensity.compute(test.x, model[[1]], G = 1, diagonal = diagonal)
  log_likelihood_Ys[,1] = model.logdensity.compute(theYs, model[[1]], G = 1, diagonal = diagonal)
  
  for(g in 2:floor(sqrt(n))){

    model[[g]] = tryCatch(densityMclust(data = train.x, G = g, modelNames),
                          error = function(err) {
                            
                            # error handler picks up where error was generated
                            print(paste("MY_ERROR:  ",err))
                            return(NA)
                          })
    #if(is.na(model[[g]])){ print("It works!")
    #  return(list(error = TRUE)) }
    if(is.na(model[[g]])){
      log_likelihood[,g] =  -10^{1000}
    }else{
      diagonal = F
      if(model[[g]]$modelName %in% c("EII","VII","EEI","VEI","EVI","VVI")){diagonal = T}
      log_likelihood[,g] = model.logdensity.compute(test.x, model[[g]], G = g, diagonal= diagonal)
      log_likelihood_Ys[,g] = model.logdensity.compute(theYs, model[[g]], G = g, diagonal = diagonal)
      }
    #print(model[[g]]$modelName)
  }
 
  # Calculating KL distance
   
  mean_log_likelihood = colMeans(log_likelihood)
  mean_likelihood = colMeans(exp(log_likelihood))
  
  # Calculating the L2 norm
  
  gYs = dt(theYs, t, log = T)
  gYs = rowSums(gYs)
  log_likelihood_Ys = 2*log_likelihood_Ys - gYs
  likelihoodYs = exp(log_likelihood_Ys)
  mean_likelihoodYs = colMeans(likelihoodYs)
  compare_likelihoods = mean_likelihoodYs - 2*mean_likelihood
  
  if(is.null(modelNames)){modelNames = model[[2]]$modelName}
  print(modelNames)
  
  if(modelNames == "EII"){
    no.params = (d + 1)*seq(1:Kn)
  }else if(modelNames == "VII"){
    no.params = (d + 2)*seq(1:Kn) - 1
  }else if(modelNames == "EEI"){
    no.params = (d + 1)*seq(1:Kn) + d - 1
  }else if(modelNames == "VEI"){
    no.params = (d + 2)*seq(1:Kn) + d - 1
  }else if(modelNames == "EVI"){
    no.params = (2*d)*seq(1:Kn) - 1 
  }else if(modelNames == "VVI"){
    no.params = (2*d + 1)*seq(1:Kn) - 1
  }else if(modelNames == "EEE"){
    no.params = (d + 1)*seq(1:Kn) - 1 + d*(d+1)/2
  }else if(modelNames == "EVE"){
    no.params = (d + 1)*seq(1:Kn) - 1 + d*(d+1)/2 + (d-1)*(seq(1:Kn) - 1)
  }else if(modelNames == "VEE"){
    no.params = (d + 1)*seq(1:Kn) - 1 + d*(d+1)/2 + seq(0:(Kn-1))
  }else if(modelNames == "VVE"){
    no.params = (d + 1)*seq(1:Kn) - 1 + d*(d+1)/2 + seq(0:(Kn-1)) + (d-1)*seq(0:(Kn-1))
  }else if(modelNames == "EEV"){
    no.params = (2 + d*(d+1)/2)*seq(1:Kn) - 1 - seq(0:(Kn-1))
  }else if(modelNames == "VEV"){
    no.params = (2 + d*(d+1)/2)*seq(1:Kn) - 1
  }else if(modelNames == "EVV"){
    no.params = (d + d*(d+1)/2)*seq(1:Kn) - 1
  }else if(modelNames == "VVV"){
    no.params = (d + 1 + d*(d+1)/2)*seq(1:Kn) - 1
  }
  
  # Minimum AIC
  AIC = 2*no.params - 2*n*mean_log_likelihood
  Min_AIC = which.min(AIC)
  
  # Minimum BIC
  BIC = no.params*log(n) - 2*n*mean_log_likelihood
  Min_BIC = which.min(BIC)
  
  max_index = rep(0, (Kn - 1))
  min_index = rep(0, (Kn - 1))
  index1 = 1
  index2 = 1
  while(index1 < Kn){
    s = index1 + which.max(mean_log_likelihood[(index1+1):Kn])
    max_index[index1:(s - 1)] = s
    index1 = s
  }
  while(index2 < Kn){
    s = index2 + which.min(compare_likelihoods[(index2+1):Kn])
    min_index[index2:(s - 1)] = s
    index2 = s
  }
  
  foundKSreject = 0
  foundL2reject = 0
  for(j in 1:(Kn-1)){
    if(foundKSreject == 0){
      Rjs = log_likelihood[,(max_index[j])] - log_likelihood[,j]
      if((mean(Rjs) - mean_log_likelihood[(max_index[j])] + mean_log_likelihood[j])>10^{-5}){
        print("Something is really wrong!")
        print(mean(Rjs))
        print(mean_log_likelihood[(max_index[j])] - mean_log_likelihood[j])
      }
      tau_hat = sd(Rjs)
      if(mean(Rjs) < (qnorm(1 - (alpha/(Kn - j)))* tau_hat/sqrt(n))){
        simple = j
        foundKSreject = 1
      }
    }
    if(foundL2reject == 0){
      Ujs = exp(log_likelihood[,(min_index[j])]) - exp(log_likelihood[,j])
      pnormsqs = likelihoodYs[,j] - likelihoodYs[,(min_index[j])]
      #rho_hat = sqrt((var(pnormsqs)/5000) + (4*var(Ujs)/n))
      rho_hat = 2*sd(Ujs)/sqrt(n)
      if(compare_likelihoods[j] - compare_likelihoods[(min_index[j])]
         < (qnorm(1 - (alpha/(Kn - j)))* rho_hat)){
        simple_L2 = j
        foundL2reject = 1
      }
    }
  }
  if(foundKSreject == 0){ simple = Kn}
  if(foundL2reject == 0){ simple_L2 = Kn}
  return(list(simple = simple,simple_L2 = simple_L2, Min_AIC = Min_AIC, Min_BIC = Min_BIC))
}

Model.selection.example <- function(n_clust, d, k, mu = rep(0,d), sds = rep(1,d), min.dist = 1,
                                    alpha = 0.05, K = 100, modelNames = NULL){
  
  n = sum(n_clust)
  sample_no = c()
  for(clust in 1:k){
    sample_no = c(sample_no, rep(clust,n_clust[clust])) 
  }
  
  Simple = rep(0,K)
  Simple_L2 = rep(0,K)
  AIC = rep(0,K)
  BIC = rep(0,K)
  
  which.comp = sample(sample_no,size=n)
  found = 0
  while(found == 0){
    mus = mvrnorm(n=4, mu, Sigma = diag(sds))
    distance.means = dist(mus)
    if(min(distance.means) > min.dist){
      found = 1
    }
  }
  
  
  for(i in 1:K){
    
    #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
    #which.comp = sample(sample_no,size=n)
    #found = 0
    #while(found == 0){
    #  mus = mvrnorm(n=4, mu, Sigma = diag(sds))
    #  distance.means = dist(mus)
    #  if(min(distance.means) > min.dist){
    #    found = 1
    #  }
   # }
    
    
    data = mvrnorm(n, mu = rep(0,d), Sigma=diag(rep(1,d)))
    data = t(sapply(c(1:n), function(i){return(data[i,] + mus[which.comp[i],])}) )
    #data <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
    train.x = data[1:floor(n/2),]
    test.x = data[(floor(n/2)+1):n,]
    
    Cluster_number = Model.selection.approach(train.x, test.x, alpha, modelNames)  
    
    Simple[i] = Cluster_number$simple
    Simple_L2[i] = Cluster_number$simple_L2
    AIC[i] = Cluster_number$Min_AIC
    BIC[i] = Cluster_number$Min_BIC
    
    print(i)
  }
  return(list(Simple = Simple, Simple_L2= Simple_L2, AIC = AIC, BIC = BIC))
}