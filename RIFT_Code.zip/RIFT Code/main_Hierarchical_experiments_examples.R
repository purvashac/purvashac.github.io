rm(list=ls())
setwd("~/Documents/Clustering research")
library(ggplot2)
library(reshape2)
library(tidyr)
library(dplyr)
source("Hierarchical_experiments_examples.R")

# Square example: (d = 2, delta = 3)
d = 2
k = 4
delta = 3
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Tetra", simp.trunc = T, 
                                                  topdown = T, bottomup = T)
#table(Hierarchical_top_down1$Simple_topdown)
#table(Hierarchical_top_down1$Simple_Median)
#table(Hierarchical_top_down1$Marron)
#table(Hierarchical_top_down1$Marron_SigClust)
#table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_1_trun_bottomup.csv")
df = read.csv("Top_down_Marron_compare_1_trun_bottomup.csv")
df = as.data.frame(df)
table(df$Simple_topdown)
table(df$Simple_Median_topdown)
table(df$Marron_topdown)
table(df$Marron_SigClust_topdown)
table(df$Mardia_topdown)
table(df$Simple_bottomup)
table(df$Simple_Median_bottomup)
table(df$Marron_bottomup)
table(df$Marron_SigClust_bottomup)
table(df$Mardia_bottomup)
df = read.csv("Top_down_Marron_compare_1.csv")
df = as.data.frame(df)

# Square example 2: (d = 2, delta = 4)
d = 2
k = 4
delta = 4
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Square", simp.trunc = T, 
                                                  topdown = T, bottomup = T)
#Hierarchical_top_down1_SigClust = hierarchical_experiments_just_SigClust(d, k, delta, arr = "Square", simp.trunc = T)
#table(Hierarchical_top_down1$Simple)
#table(Hierarchical_top_down1$Simple_Median)
#table(Hierarchical_top_down1$Marron)
#table(Hierarchical_top_down1$Marron_SigClust)
#table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_2_trun_bottomup.csv")
df = read.csv("Top_down_Marron_compare_2_trun_bottomup.csv")
df = as.data.frame(df)
table(df$Simple_topdown)
table(df$Simple_Median_topdown)
table(df$Marron_topdown)
table(df$Marron_SigClust_topdown)
table(df$Mardia_topdown)
table(df$Simple_bottomup)
table(df$Simple_Median_bottomup)
table(df$Marron_bottomup)
table(df$Marron_SigClust_bottomup)
table(df$Mardia_bottomup)
df = read.csv("Top_down_Marron_compare_2.csv")
df = as.data.frame(df)
table(df$Marron)

#Hierarchical_top_down1_SigClust = hierarchical_experiments_just_SigClust(d, k, delta, arr = "Square", simp.trunc = T)
#df = read.csv("Top_down_Marron_compare_2_trun.csv")
#df = data.frame(df)
#df$Marron_SigClust = Hierarchical_top_down1_SigClust$Marron_SigClust
#write.csv(df, "Top_down_Marron_compare_2_trun.csv")

# Square example 3: (d = 2, delta = 6)
d = 2
k = 4
delta = 6
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Square", simp.trunc = T, 
                                                  topdown = T, bottomup = T)
#table(Hierarchical_top_down1$Simple)
#table(Hierarchical_top_down1$Simple_Median)
#table(Hierarchical_top_down1$Marron)
#table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_3_trun_bottomup.csv")
df = read.csv("Top_down_Marron_compare_3_trun_bottomup.csv")
df = as.data.frame(df)
table(df$Simple_topdown)
table(df$Simple_Median_topdown)
table(df$Marron_topdown)
table(df$Marron_SigClust_topdown)
table(df$Mardia_topdown)
table(df$Simple_bottomup)
table(df$Simple_Median_bottomup)
table(df$Marron_bottomup)
table(df$Marron_SigClust_bottomup)
table(df$Mardia_bottomup)
df = read.csv("Top_down_Marron_compare_3.csv")
df = as.data.frame(df)
table(df$Marron)

#Hierarchical_top_down1_SigClust = hierarchical_experiments_just_SigClust(
#  d, k, delta,arr = "Square", simp.trunc = T)
#df = read.csv("Top_down_Marron_compare_3_trun.csv")
#df = data.frame(df)
#df$Marron_SigClust = Hierarchical_top_down1_SigClust$Marron_SigClust
#write.csv(df, "Top_down_Marron_compare_3_trun.csv")


# Tetrahedral example 1: (d = 3, delta = 4)
d = 3
k = 4
delta = 4
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Tetra", simp.trunc = T, 
                                                  topdown = T, bottomup = T)
#table(Hierarchical_top_down1$Simple)
#table(Hierarchical_top_down1$Simple_Median)
#table(Hierarchical_top_down1$Marron)
#table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_tetra_1_trun_bottomup.csv")
df = read.csv("Top_down_Marron_compare_tetra_1_trun_bottomup.csv")
df = as.data.frame(df)
table(df$Simple_topdown)
table(df$Simple_Median_topdown)
table(df$Marron_topdown)
table(df$Marron_SigClust_topdown)
table(df$Mardia_topdown)
table(df$Simple_bottomup)
table(df$Simple_Median_bottomup)
table(df$Marron_bottomup)
table(df$Marron_SigClust_bottomup)
table(df$Mardia_bottomup)
df = read.csv("Top_down_Marron_compare_tetra_1.csv")
df = as.data.frame(df)
table(df$Marron)

#Hierarchical_top_down1_SigClust = hierarchical_experiments_just_SigClust(
#  d, k, delta,arr = "Tetra", simp.trunc = T)
#df = read.csv("Top_down_Marron_compare_tetra_1_trun.csv")
#df = data.frame(df)
#df$Marron_SigClust = Hierarchical_top_down1_SigClust$Marron_SigClust
#write.csv(df, "Top_down_Marron_compare_tetra_1_trun.csv")

# Tetrahedral example 2: (d = 3, delta = 5)
d = 3
k = 4
delta = 5
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Tetra", simp.trunc = T, 
                                                  topdown = T, bottomup = T)
#table(Hierarchical_top_down1$Simple)
#table(Hierarchical_top_down1$Simple_Median)
#table(Hierarchical_top_down1$Marron)
#table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_tetra_2_trun_bottomup.csv")
df = read.csv("Top_down_Marron_compare_tetra_2_trun_bottomup.csv")
df = as.data.frame(df)
table(df$Simple_topdown)
table(df$Simple_Median_topdown)
table(df$Marron_topdown)
table(df$Marron_SigClust_topdown)
table(df$Mardia_topdown)
table(df$Simple_bottomup)
table(df$Simple_Median_bottomup)
table(df$Marron_bottomup)
table(df$Marron_SigClust_bottomup)
table(df$Mardia_bottomup)
#df = read.csv("Top_down_Marron_compare_tetra_2.csv")
#df = as.data.frame(df)
#table(df$Marron)

# Plots for proposal presentation

df2 = df[,c(2,3,5,6)]
colnames(df2) = c("RIFT", "M-RIFT", "Trunc. SigClust", "SigClust")
df3 = gather(df2, algo, clusts)
df3$clusts[301:400] = c(rep(1,71), rep(4,7), rep(5, 4), rep(6, 18))
df4 = df3
df4$clusts = as.character(df4$clusts)
df4$clusts[which(df3$clusts >=6)] = "Greater than 5"


plot = ggplot(data=df4, aes(x=algo, fill=clusts)) +
  geom_bar(stat="count")+
  scale_fill_brewer(palette="Paired", drop=FALSE)+
  theme_minimal()+labs( x = "Algorithm", y = "No. of simulations", fill = "No. of clusters\n") +
  scale_x_discrete(drop=FALSE)


pdf("HRIFT_plot_v2.pdf", width = 5, height = 3)
plot
dev.off()


#Hierarchical_top_down1_SigClust = hierarchical_experiments_just_SigClust(
#  d, k, delta,arr = "Tetra", simp.trunc = T)
#df = read.csv("Top_down_Marron_compare_tetra_2_trun.csv")
#df = data.frame(df)
#df$Marron_SigClust = Hierarchical_top_down1_SigClust$Marron_SigClust
#write.csv(df, "Top_down_Marron_compare_tetra_2_trun.csv")

# Square example 4: (d = 100, delta = 8)
d = 100
k = 4
delta = 8
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Tetra", simp.trunc = F)
table(Hierarchical_top_down1$Simple)
table(Hierarchical_top_down1$Simple_Median)
table(Hierarchical_top_down1$Marron)
table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_tetra_3.csv")

# Square example 5: (d = 100, delta = 10)
d = 100
k = 4
delta = 100
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Tetra", simp.trunc = F)
table(Hierarchical_top_down1$Simple)
table(Hierarchical_top_down1$Simple_Median)
table(Hierarchical_top_down1$Marron)
table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_tetra_4.csv")

# Square example 4: (d = 100, delta = 8)
d = 100
k = 4
delta = 8
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Square", simp.trunc = T)
table(Hierarchical_top_down1$Simple)
table(Hierarchical_top_down1$Simple_Median)
table(Hierarchical_top_down1$Marron)
table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_4.csv")

# Square example 5: (d = 100, delta = 10)
d = 100
k = 4
delta = 10
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Square")
table(Hierarchical_top_down1$Simple)
table(Hierarchical_top_down1$Simple_Median)
table(Hierarchical_top_down1$Marron)
table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_5.csv")

# Square example 6: (d = 100, delta = 20)
d = 100
k = 4
delta = 30
set.seed(7)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, arr = "Square")
table(Hierarchical_top_down1$Simple)
table(Hierarchical_top_down1$Simple_Median)
table(Hierarchical_top_down1$Marron)
table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_6.csv")


# Tetrahedral example 7: (d = 100, delta = 400)
d = 100
k = 4
delta = 40
set.seed(7)
n_clust = rep(200,k)

Hierarchical_top_down1 = hierarchical_experiments(d, k, delta, n_clust, arr = "Tetra", simp.trunc = T, 
                                                  topdown = T, bottomup = T)
#table(Hierarchical_top_down1$Simple)
#table(Hierarchical_top_down1$Simple_Median)
#table(Hierarchical_top_down1$Marron)
#table(Hierarchical_top_down1$Mardia)
df = data.frame(Hierarchical_top_down1)
write.csv(df, "Top_down_Marron_compare_tetra_7_trun_bottomup.csv")
df = read.csv("Top_down_Marron_compare_tetra_7_trun_bottomup.csv")
df = as.data.frame(df)
table(df$Simple_topdown)
table(df$Simple_Median_topdown)
table(df$Marron_topdown)
table(df$Marron_SigClust_topdown)
table(df$Mardia_topdown)
table(df$Simple_bottomup)
table(df$Simple_Median_bottomup)
table(df$Marron_bottomup)
table(df$Marron_SigClust_bottomup)
table(df$Mardia_bottomup)
df = read.csv("Top_down_Marron_compare_tetra_1.csv")
df = as.data.frame(df)
table(df$Marron)