library(MASS)
require(mixtools)
require(mclust)
library(ggplot2)
library(grid)
library(gridExtra)
set.seed(7)

Finding.Delta = function(model, test.x){
  
  pred.test = predict(model, newdata = test.x, what = "cdens")
  test.class.D2 = sapply(1:nrow(pred.test), function(i){which.max(pred.test[i,])})
  sigma = sqrt(det(var(test.x)))
  if(length(which(test.class.D2 == 1))<2){
    sigma1 = 0
  }else{
    if(det(var(test.x[which(test.class.D2 == 1),]))<0){
      sigma1 = 0
    }else{
      sigma1 = sqrt(det(var(test.x[which(test.class.D2 == 1),])))
    }
  }
  if(length(which(test.class.D2 == 2))<2){
    sigma2 = 0
  }else{
    if(det(var(test.x[which(test.class.D2 == 2),]))<0){
      sigma2 = 0
    }else{
      sigma2 = sqrt(det(var(test.x[which(test.class.D2 == 2),])))
    }
  }
  delta = sigma - sigma1 - sigma2
  return(list(delta = delta, class = test.class.D2))
}

Resampled.Delta = function(model, test.x){
  sampled.rows = sample(1:nrow(test.x), replace = TRUE)
  test.cluster = Finding.Delta(model, test.x[sampled.rows,])
  return(test.cluster$delta)
}

MDecompTest <- function(data, alpha = 0.05){
  
  N = nrow(data)
  train.x = data[1:(N/2),]
  test.x = data[(N/2 + 1):N,]
  model = densityMclust(data = train.x, G = 2)
  train.class.D1 = model$classification
  sigma = sqrt(det(var(train.x)))
  if(length(which(train.class.D1 == 1))<2){
    sigma1 = 0
  }else{
    if(det(var(train.x[which(train.class.D1 == 1),]))<0){
      sigma1 = 0
    }else{
      sigma1 = sqrt(det(var(train.x[which(train.class.D1 == 1),])))
    }
  }
  if(length(which(train.class.D1 == 2))<2){
    sigma2 = 0
  }else{
    if(det(var(train.x[which(train.class.D1 == 2),]))<0){
      sigma2 = 0
    }else{
      sigma2 = sqrt(det(var(train.x[which(train.class.D1 == 2),])))
    }
  }
  delta0 = sigma - sigma1 - sigma2
  
  test.cluster = Finding.Delta(model, test.x)
  test.delta = test.cluster$delta
  test.class.D2 = test.cluster$class
  
  ## Bootstrapping to find the null distribution of Delta
  
  # Run the bootstrap
  B = 1000
  delta.on.real.data = test.delta
  deltas.on.resamples = replicate(B, Resampled.Delta(model, test.x))
  
  # Bootstrap confidence intervals (pivotal)
  lwr = 2*delta.on.real.data - quantile(deltas.on.resamples, 1 - alpha)[[1]]
  c = lwr
  reject = (c > 0)
  pvalue = 1 - pnorm(delta.on.real.data, 0, sd(deltas.on.resamples))
  return(list(reject = reject, pvalue = pvalue))
}

# Generating data from two clusters
set.seed(7)
N = 500
which.comp = sample(1:2,prob=c(0.5,0.5),size=N,replace=TRUE)
mus = rbind(c(-2,0),c(2,0))
sds <- c(1,10)

x <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
plot(x)
train.x = x[1:(N/2),]
test.x = x[(N/2 + 1):N,]
plot(train.x)
y = t(colMeans(train.x))
points(y, col = 2)

model = densityMclust(data = train.x, G = 2)
train.class.D1 = model$classification
sigma = sqrt(det(var(train.x)))
sigma1 = sqrt(det(var(train.x[which(train.class.D1 == 1),])))
sigma2 = sqrt(det(var(train.x[which(train.class.D1 == 2),])))
delta0 = sigma - sigma1 - sigma2

test.cluster = Finding.Delta(model, test.x)
test.delta = test.cluster$delta
test.class.D2 = test.cluster$class

## Bootstrapping to find the null distribution of Delta

# Run the bootstrap
B = 1000
alpha = 0.05
delta.on.real.data = test.delta
deltas.on.resamples = replicate(B, Resampled.Delta(model, test.x))

# Bootstrap confidence intervals (pivotal)
lwr = 2*delta.on.real.data - quantile(deltas.on.resamples, 1 - alpha)[[1]]
c = lwr
c > 0

train.x = data.frame(train.x)
test.x = data.frame(test.x)
ggplot(data = train.x, aes(x = X1, y = X2))+
  geom_point(aes(color = train.class.D1 )) + 
  ggtitle("SigClust Clustering") +
  guides(color = "none")
ggplot(data = test.x, aes(x = X1, y = X2))+
  geom_point(aes(color = test.class.D2)) + 
  ggtitle("SigClust Clustering") +
  guides(color = "none")









