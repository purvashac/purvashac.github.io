library(sigclust)

Finding.Power.tests <- function(n, mu, d, sds = rep(1,d), alpha = 0.05, K = 100, symmetry = T){
  
  reject_simple = rep(0,K)
  reject_simple_median = rep(0,K)
  reject_Mardia = rep(0,K)
  reject_NN = rep(0,K)
  reject_NN_KS = rep(0,K)
  reject_Marron = rep(0,K)
  
  pvalue_simple = rep(1,K)
  pvalue_simple_median = rep(1,K)
  pvalue_Mardia = rep(1,K)
  pvalue_NN = rep(1,K)
  pvalue_NN_KS = rep(1,K)
  pvalue_Marron = rep(1,K)
  #reject_MTest = rep(1,K)
  
  for(i in 1:K){
    
    #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
    which.comp = sample(1:2,prob=c(0.5,0.5),size=n,replace=TRUE)
    if(symmetry){
      mus = rbind(-mu,mu)
    }else{
      mus = rbind(rep(0,length(mu)),mu)
    }
    
    data = mvrnorm(n, mu = rep(0,ncol(mus)), Sigma=diag(sds))
    data = t(sapply(c(1:n), function(i){return(data[i,] + mus[which.comp[i],])}) )
    #data <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
    train.x = data[1:(9*n/10),]
    test.x = data[((9*n/10)+1):n,]
    #train.x = data[1:(n/2),]
    #test.x = data[((n/2)+1):n,]
    model1 = densityMclust(data = train.x, G = 1, modelNames = "EEI")
    if(norm(mus[1,]-mus[2,], type = "2") == 0){
      model2 = fitting.mixture.model(data = train.x, G = 2, modelNames = "EEI",
                                     starting.means = rbind(mus[1,]-rep(0.1,ncol(mus)), 
                                                            mus[2,]+rep(0.1,ncol(mus))),
                                     starting.variance = diag(rep(1, ncol(data))))
    }else{
      model2 = fitting.mixture.model(data = train.x, G = 2, modelNames = "EEI",
                                     starting.means = mus,
                                     starting.variance = diag(rep(1, ncol(data))))
    }
    
    #model2 = densityMclust(data = train.x, G = 2, modelNames = "VVI")
    Ri = Ri.compute(test.x, model1, model2)
    log.truncation.ratio = 0
    simple = KL.Test1.mixture(Ri, log.truncation.ratio, alpha)
    simple_median = KL.Test2.mixture.median(Ri, log.truncation.ratio, alpha)
    Mardia = asym.Kurtosis.test(data, alpha)
    #NN = asym.NN.test(test.x, model1, alpha = 0.05)
    #NN_KS = KS.NN.test(test.x, model1, alpha = 0.05)
    #fit.kmeans = kmeans(train.x, centers = 1)
    #centers = fit.kmeans$centers
    #WSS = fit.kmeans$withinss
    #Marron = one.step.recursive.clustering(1, centers, WSS, components = 2, train.x, test.x)
    Marron = sigclust(data, nsim = 1000)
    
    pvalue_simple[i] = simple$pvalue
    print(simple$pvalue)
    pvalue_simple_median[i] = simple_median$pvalue
    pvalue_Mardia[i] = Mardia$pvalue
    #pvalue_NN[i] = NN$pvalue
    #pvalue_NN_KS[i] = NN_KS$pvalue
    pvalue_Marron[i] = slot(Marron, "pval")
    
    if(simple$reject == T){
      reject_simple[i] = 1
    }
    if(simple_median$reject == T){
      reject_simple_median[i] = 1
    }
    if(Mardia$reject == T){
      reject_Mardia[i] = 1
    }
    #if(NN$reject == FALSE){
    #  reject_NN[i] = 0
    #}
    #if(NN_KS$reject == FALSE){
    #  reject_NN_KS[i] = 0
    #}
    if(slot(Marron, "pval") < alpha){
      reject_Marron[i] = 1
    }
    print(i)
  }
  return(list(reject_simple = reject_simple, reject_simple_median = reject_simple_median, 
              reject_Mardia = reject_Mardia, reject_NN = reject_NN, 
              reject_NN_KS = reject_NN_KS, reject_Marron = reject_Marron,
              pvalue_simple = pvalue_simple, pvalue_simple_median = pvalue_simple_median, 
              pvalue_Mardia = pvalue_Mardia, pvalue_NN = pvalue_NN, 
              pvalue_NN_KS = pvalue_NN_KS, pvalue_Marron = pvalue_Marron))
}