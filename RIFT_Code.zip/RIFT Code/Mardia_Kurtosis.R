library(MASS)
library(ggplot2)
library(grid)
library(gridExtra)

Test.Statistic <- function(data){
  
  d = ncol(data)
  n = nrow(data)
  Sn = var(data)
  if(det(Sn) < 0.0001){
    Sn = Sn + diag(x=0.001, nrow = nrow(Sn))
  }
  Sninve = tryCatch(solve(Sn),
                    error = function(err) {
                      
                      # error handler picks up where error was generated
                      print(paste("MY_ERROR:  ",err))
                      return(solve(Sn + diag(rep(0.001, nrow(Sn)))))
                    })
  Xbar = colMeans(data)
  scaling = sapply(c(1:n),
                     function(i){
                       x = as.vector((data[i,] - Xbar), mode = "numeric")
                       return((t(x) %*% Sninve %*% x)^2)
                       })
  
  kurtosis = mean(scaling)
  Teststat = sqrt(n)*(kurtosis - (d*(d+2)))/sqrt(8*d*(d+2))
  return(Teststat)
}

asym.Kurtosis.test <- function(data, alpha = 0.05){
  
  Teststat = Test.Statistic(data)
  reject = (abs(Teststat) > qnorm(1 - (alpha/2)))
  pvalue = 2*pnorm(-abs(Teststat))
  return(list(reject = reject, pvalue = pvalue))
}

# Example
#data = mvrnorm(n=1000,mu=c(0,0),Sigma=diag(1,2))
#asym.Kurtosis.test(data)
