#rm(list=ls())
library(mixtools)
library(mclust)
setwd("~/Documents/Clustering research")
source("main_bottomup_hierarchical.R")
source("main_topdown_hierarchical.R")
source("main_topdown_Marron.R")
source("SimulComparision.R")

hierarchical_experiments <- function(d, k, delta, n_clust = rep(50,k), K = 100, alpha = 0.05,
                                     arr = "Square", simp.trunc = F, topdown = T, bottomup = F){
  if(d < 3 && arr == "Tetra"){
    print("Two dimensional Tetrahedron does not exist! Defaulting to Square.")
    arr = "Square"
  }
  if(arr == "Square"){
    mus = rbind(c(0, 0, rep(0,(d - 2))), 
                c(0, delta, rep(0,(d - 2))),
                c(delta, 0, rep(0,(d - 2))),
                c(delta, delta, rep(0,(d - 2))))
  }else if(arr == "Tetra"){
    mus = rbind(c(0, 0, 0, rep(0,(d - 3))), 
                c(0, delta, delta, rep(0,(d - 3))),
                c(delta, delta, 0, rep(0,(d - 3))),
                c(delta, 0, delta, rep(0,(d - 3))))
  }else{
    mus = mvrnorm(n = k, rep(0,d), Sigma = diag(rep(1,d)))
  }
  
  n = sum(n_clust)
  sample_no = c()
  for(clust in 1:k){
    sample_no = c(sample_no, rep(clust,n_clust[clust])) 
  }
  
  Simple_topdown = rep(1000,K)
  Simple_Median_topdown = rep(1000,K)
  Mardia_topdown = rep(1000,K)
  Marron_topdown = rep(1000,K)
  Marron_SigClust_topdown = rep(1000,K)
  Simple_bottomup = rep(1000,K)
  Simple_Median_bottomup = rep(1000,K)
  Mardia_bottomup = rep(1000,K)
  Marron_bottomup = rep(1000,K)
  Marron_SigClust_bottomup = rep(1000,K)
  
  for(i in 1:K){
    
    #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
    which.comp = sample(sample_no,size=n)
    
    
    data = mvrnorm(n, mu = rep(0,d), Sigma=diag(rep(1,d)))
    for(comp in 1:k){
      idx = which(which.comp == comp)
      data[idx,] = data[idx,] + matrix(rep(mus[comp,], length(idx)), 
                                       nrow = length(idx), byrow = T)
    }
    #data = t(sapply(c(1:n), function(i){return(data[i,] + mus[which.comp[i],])}) )
    #data <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
    #train.x = data[1:floor(n/2),]
    #test.x = data[(floor(n/2)+1):n,]
    
    if(topdown){
      
      Hierarchical_cluster = Topdownclustering(data, alpha)
      error.trigger1 = Hierarchical_cluster$error.trigger
      Hierarchical_cluster_Marron = TopdownclusteringMarron(data, alpha, truncation = simp.trunc)
      Hierarchical_cluster_Marron_SigClust = TopdownclusteringMarron(data, alpha, truncation = F)
      #error.trigger2 = Hierarchical_cluster_Marron_SigClust$error.trigger
      
      if(error.trigger1 == 0){
        
        x = output_tree(Hierarchical_cluster$test.reject.list,
                        Hierarchical_cluster$parents, method = "simple")
        y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
        Simple_topdown[i] = length(which(!y %in% x))
        
        x = output_tree(Hierarchical_cluster$test.reject.list,
                        Hierarchical_cluster$parents, method = "simple_median")
        y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
        Simple_Median_topdown[i] = length(which(!y %in% x))
        
        x = output_tree(Hierarchical_cluster$test.reject.list,
                        Hierarchical_cluster$parents, method = "Mardia")
        y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
        Mardia_topdown[i] = length(which(!y %in% x))
      }
      
      Marron_topdown[i] = length( Hierarchical_cluster_Marron$leaf.nodes)
      
      #if(error.trigger2 == 0){
      #  Marron_SigClust_topdown[i] = length(Hierarchical_cluster_Marron_SigClust$leaf.nodes)
      #}
      Marron_SigClust_topdown[i] = length(Hierarchical_cluster_Marron_SigClust$leaf.nodes)
    }
    
    if(bottomup){
      
      Hierarchical_cluster = Bottomupclustering(data, alpha)
      error.trigger1 = Hierarchical_cluster$error.trigger
      Hierarchical_cluster_Marron = BottomupclusteringMarron(data, alpha, truncation = simp.trunc)
      Hierarchical_cluster_Marron_SigClust = BottomupclusteringMarron(data, alpha, truncation = F)
      #error.trigger2 = Hierarchical_cluster_Marron_SigClust$error.trigger
      
      if(error.trigger1 == 0){
        
        x = output_tree(Hierarchical_cluster$test.reject.list,
                        Hierarchical_cluster$parents, method = "simple")
        y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
        Simple_bottomup[i] = length(which(!y %in% x))
        
        x = output_tree(Hierarchical_cluster$test.reject.list,
                        Hierarchical_cluster$parents, method = "simple_median")
        y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
        Simple_Median_bottomup[i] = length(which(!y %in% x))
        
        x = output_tree(Hierarchical_cluster$test.reject.list,
                        Hierarchical_cluster$parents, method = "Mardia")
        y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
        Mardia_bottomup[i] = length(which(!y %in% x))
      }
      
      Marron_bottomup[i] = length( Hierarchical_cluster_Marron$leaf.nodes)
      
      #if(error.trigger2 == 0){
      #  Marron_SigClust_bottomup[i] = length(Hierarchical_cluster_Marron_SigClust$leaf.nodes)
      #}
      
      Marron_SigClust_bottomup[i] = length(Hierarchical_cluster_Marron_SigClust$leaf.nodes)
    }
    
    print(i)
  }
  return(list(Simple_topdown = Simple_topdown, Simple_Median_topdown = Simple_Median_topdown,
              Mardia_topdown = Mardia_topdown, Marron_topdown = Marron_topdown,
              Marron_SigClust_topdown = Marron_SigClust_topdown, Simple_bottomup = Simple_bottomup,
              Simple_Median_bottomup = Simple_Median_bottomup,
              Mardia_bottomup = Mardia_bottomup, Marron_bottomup = Marron_bottomup,
              Marron_SigClust_bottomup = Marron_SigClust_bottomup))
}

hierarchical_experiments_just_SigClust <- function(d, k, delta, n_clust = rep(50,k), K = 100, alpha = 0.05,
                                     arr = "Square", simp.trunc = F){
  if(d < 3 && arr == "Tetra"){
    print("Two dimensional Tetrahedron does not exist! Defaulting to Square.")
    arr = "Square"
  }
  if(arr == "Square"){
    mus = rbind(c(0, 0, rep(0,(d - 2))), 
                c(0, delta, rep(0,(d - 2))),
                c(delta, 0, rep(0,(d - 2))),
                c(delta, delta, rep(0,(d - 2))))
  }else if(arr == "Tetra"){
    mus = rbind(c(0, 0, 0, rep(0,(d - 3))), 
                c(0, delta, delta, rep(0,(d - 3))),
                c(delta, delta, 0, rep(0,(d - 3))),
                c(delta, 0, delta, rep(0,(d - 3))))
  }else{
    mus = mvrnorm(n = k, rep(0,d), Sigma = diag(rep(1,d)))
  }
  
  n = sum(n_clust)
  sample_no = c()
  for(clust in 1:k){
    sample_no = c(sample_no, rep(clust,n_clust[clust])) 
  }
  
  Marron_SigClust = rep(0,K)
  
  for(i in 1:K){
    
    #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
    which.comp = sample(sample_no,size=n)
    
    
    data = mvrnorm(n, mu = rep(0,d), Sigma=diag(rep(1,d)))
    for(comp in 1:k){
      idx = which(which.comp == comp)
      data[idx,] = data[idx,] + matrix(rep(mus[comp,], length(idx)), 
                                       nrow = length(idx), byrow = T)
    }
    #data = t(sapply(c(1:n), function(i){return(data[i,] + mus[which.comp[i],])}) )
    #data <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
    #train.x = data[1:floor(n/2),]
    #test.x = data[(floor(n/2)+1):n,]
    
    Hierarchical_cluster_Marron_SigClust = TopdownclusteringMarron_SigClust(data, alpha)
    
    Marron_SigClust[i] = length(Hierarchical_cluster_Marron_SigClust$leaf.nodes)
    
    print(i)
  }
  return(list(Marron_SigClust = Marron_SigClust))
}

