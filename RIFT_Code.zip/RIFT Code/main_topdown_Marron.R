library(MASS)
library(ggplot2)
library(grid)
library(gridExtra)
library(mixtools)
library(mclust)
library(sigclust)
#library(mixtools)
#library(mclust)
#setwd("~/Documents/Clustering research")
#source("Unconditional_Simple_Test.R")
#source("Mardia_Kurtosis.R")
#source("Zhou_NN_Test.R")
#source("MTest_v1.R")
#source("Untitled.R")

CI.compute <- function(y, components){
  fit.kmeans = kmeans(y, centers = components)
  #  numerator = 0
  #  for(k in 1:components){
  #    xC = y[which(fit.kmeans$cluster == k),]
  #    diffC = sapply(seq(1,nrow(xC)), function(i){xC[i,] - fit.kmeans$centers[k,]})
  #    numerator = numerator + sum(diffC^2)
  #  }
  #  diff.whole = sapply(seq(1,nrow(y)), function(i){y[i,] - colMeans(y)})
  #  denominator = sum(diff.whole^2)
  return(fit.kmeans$tot.withinss/ fit.kmeans$totss)
}

predict.class <- function(x, centers){
  
  #centers = model$centers
  if(nrow(centers) == 1) return(1)
  else{
    dist.centers = rep(0, nrow(centers))
    for(i in 1: nrow(centers)){
      dist.centers[i] = dist(rbind(x, centers[i,]))
    }
    return(which.min(dist.centers))
  }
  
}

one.step.recursive.clustering <- function(i, centers, WSS, components = 2, train.x, test.x, 
                                          truncation = F){
  
  test.cluster = apply(test.x, MARGIN = 1, function(x){predict.class(x, centers)} )
  if(truncation){
    if(length(which(test.cluster == i))<3){
      return(list(p.value = 0, Simul.CI = c(0)))
    }
    test.x = test.x[which(test.cluster == i),]
  }
  CI.sample = CI.compute(test.x, components)
  d = ncol(train.x)
  train.cluster = apply(train.x, MARGIN = 1, function(x){predict.class(x, centers)} )
  train.x = train.x[which(train.cluster == i),]
  sigmasq = diag(var(train.x))
  Simul.CI = rep(1000, 50)
  for(k in 1:50){
    B = 100
    if(truncation){
      simulated.x = matrix(0, nrow = B, ncol = d)
      for(j in 1:B){
        cluster.index = 0
        while(cluster.index!= i){
          simulated.x[j,] =
            mvrnorm(1, centers[i,], diag(sigmasq))
          cluster.index = predict.class(simulated.x[j,], centers)
        }
      }
    }else{
      simulated.x = mvrnorm(B, centers[i,], diag(sigmasq))
    }
    Simul.CI[k] = CI.compute(simulated.x, components)
  }
  p.value = pnorm(CI.sample, mean(Simul.CI), sd(Simul.CI))
  return(list(p.value = p.value, Simul.CI = Simul.CI))
}


TopdownclusteringMarron <- function(data, alpha = 0.05, truncation = F){
  
  
  # Defining the outputs
  model.fit = list()
  train.list = list()
  test.list = list()
  test.reject.list = list()
  children.list = list()
  parent.node = c(0)
  leaf.nodes = c(1)
  which.child = c(1)
  parent.index = 1
  children.index = 2
  n = nrow(data)
  a = floor(n/2)
  
  train.x = data[1:a,]
  test.x = data[(a+1):n,]
  train.list[[parent.index]] = train.x
  test.list[[parent.index]] = test.x
  ntrain = c(nrow(train.x))
  ntest = c(nrow(test.x))
  model.fit[[parent.index]] = kmeans(train.x, centers = 1)
  all.centers = model.fit[[parent.index]]$centers
  all.WSS = model.fit[[parent.index]]$withinss
  
  while(parent.index < children.index && children.index < 17){
    
    train.x = train.list[[parent.index]]
    test.x = test.list[[parent.index]]
    centers = all.centers[leaf.nodes,]
    
    WSS = all.WSS[leaf.nodes]
    which.leaf = which(leaf.nodes == parent.index)
    if(length(leaf.nodes)==1){
      centers = t(as.matrix(centers))
    }
    fit = one.step.recursive.clustering(which.leaf, centers, WSS, components = 2, 
                                        train.x, test.x, truncation)
    alpha.new = alpha/(2^(2*(floor(log2(parent.index)))+1))
    reject = (fit$p.value < alpha.new)
    test.reject.list[[parent.index]] = list(reject = reject, fit = fit)
    
    if(reject == T){
      
      fit.kmeans = kmeans(train.x, centers = 2)
      train.cluster = apply(train.x, MARGIN = 1, function(x){predict.class(x, fit.kmeans$centers)} )
      test.cluster = apply(test.x, MARGIN = 1, function(x){predict.class(x, fit.kmeans$centers)} )
      
      if(length(which(train.cluster == 1)) > 2 && length(which(train.cluster == 2)) > 2 &&
         length(which(test.cluster == 1)) > 2 && length(which(test.cluster == 2)) > 2){
        
        train.x1 = train.x[which(train.cluster == 1),]
        train.x2 = train.x[which(train.cluster == 2),]
        test.x1 = test.x[which(test.cluster == 1),]
        test.x2 = test.x[which(test.cluster == 2),]
        
        parent.node = c(parent.node, rep(parent.index, 2))
        which.child = c(which.child, 1, 2)
        ntrain = c(ntrain, nrow(train.x1), nrow(train.x2))
        ntest = c(ntest, nrow(test.x1), nrow(test.x2))
        children.list[[parent.index]] = c(children.index, children.index + 1)
        all.centers = rbind(all.centers,fit.kmeans$centers)
        all.WSS = c(WSS, fit.kmeans$withinss)
        leaf.nodes = c(leaf.nodes[-which.leaf], children.index, children.index + 1)
        
        train.list[[children.index]] = train.x1
        test.list[[children.index]] = test.x1
        model.fit[[children.index]] = fit.kmeans
        children.list[[children.index]] = c(0,0)
        test.reject.list[[children.index]] = list(reject = F, fit = NULL)
        children.index = children.index + 1
        
        train.list[[children.index]] = train.x2
        test.list[[children.index]] = test.x2
        model.fit[[children.index]] = fit.kmeans
        children.list[[children.index]] = c(0,0)
        test.reject.list[[children.index]] = list(reject = F, fit = NULL)
        children.index = children.index + 1
      }else{
        test.reject.list[[parent.index]]$reject = FALSE
      }
    }
    parent.index = parent.index + 1
  }
  return(list(model.fit = model.fit, leaf.nodes = leaf.nodes, train.cluster = train.list,
              test.cluster = test.list, test.reject.list = test.reject.list,
              parents = parent.node, all.centers = all.centers, all.WSS = all.WSS,
              which.child = which.child, children.list = children.list,
              ntrain = ntrain, ntest = ntest))
}

TopdownclusteringMarron_SigClust <- function(data, alpha = 0.05){
  
  
  # Defining the outputs
  model.fit = list()
  data.list = list()
  test.reject.list = list()
  children.list = list()
  parent.node = c(0)
  leaf.nodes = c(1)
  which.child = c(1)
  parent.index = 1
  children.index = 2
  n = nrow(data)
  
  data.list[[parent.index]] = data
  
  while(parent.index < children.index && children.index < 17){
    
    data.x = data.list[[parent.index]]
    error.trigger = 0
    fit = tryCatch(sigclust(data.x, nsim = 1000),
             error = function(err) {
               
               # error handler picks up where error was generated
               print(paste("MY_ERROR:  ",err))
               return(NA)
               })
    if(is.na(fit)){return(list(error.trigger = 1))}
    alpha.new = alpha/(2^(2*(floor(log2(parent.index)))+1))
    reject = (slot(fit, "pval") < alpha.new)
    test.reject.list[[parent.index]] = list(reject = reject, fit = fit)
    which.leaf = which(leaf.nodes == parent.index)
    
    if(reject == T){
      
      model.fit[[parent.index]] = kmeans(data.list[[parent.index]], centers = 2)
      cluster = model.fit[[parent.index]]$cluster
      
      if(length(which(cluster == 1)) > 2 && length(which(cluster == 2)) > 2){
        
        data.x1 = data.list[[parent.index]][which(cluster == 1),]
        data.x2 = data.list[[parent.index]][which(cluster == 2),]
        
        
        parent.node = c(parent.node, rep(parent.index, 2))
        which.child = c(which.child, 1, 2)
        children.list[[parent.index]] = c(children.index, children.index + 1)
        leaf.nodes = c(leaf.nodes[-which.leaf], children.index, children.index + 1)
        
        data.list[[children.index]] = data.x1
        children.list[[children.index]] = c(0,0)
        test.reject.list[[children.index]] = list(reject = F, fit = NULL)
        children.index = children.index + 1
        
        data.list[[children.index]] = data.x2
        children.list[[children.index]] = c(0,0)
        test.reject.list[[children.index]] = list(reject = F, fit = NULL)
        children.index = children.index + 1
      }else{
        test.reject.list[[parent.index]]$reject = FALSE
      }
    }
    
    
    parent.index = parent.index + 1
  }
  return(list(model.fit = model.fit, leaf.nodes = leaf.nodes, data.cluster = data.list,
              test.reject.list = test.reject.list,
              parents = parent.node, error.trigger = error.trigger,
              which.child = which.child, children.list = children.list))
}


BottomupclusteringMarron <- function(data, alpha = 0.05, truncation = F){
  
  
  # Defining the outputs
  model.fit = list()
  train.list = list()
  test.list = list()
  test.reject.list = list()
  children.list = list()
  parent.node = c(0)
  leaf.nodes = c(1)
  which.child = c(1)
  parent.index = 1
  children.index = 2
  n = nrow(data)
  a = floor(n/2)
  
  train.x = data[1:a,]
  test.x = data[(a+1):n,]
  train.list[[parent.index]] = train.x
  test.list[[parent.index]] = test.x
  ntrain = c(nrow(train.x))
  ntest = c(nrow(test.x))
  model.fit[[parent.index]] = kmeans(train.x, centers = 1)
  all.centers = model.fit[[parent.index]]$centers
  all.WSS = model.fit[[parent.index]]$withinss
  
  while(parent.index < children.index && children.index < 10
        && nrow(train.list[[parent.index]])!=0
        && nrow(test.list[[parent.index]])!=0){
    
    
    train.x = train.list[[parent.index]]
    test.x = test.list[[parent.index]]
    fit.kmeans = kmeans(train.x, centers = 2)
    train.cluster = apply(train.x, MARGIN = 1, function(x){predict.class(x, fit.kmeans$centers)})
    test.cluster = apply(test.x, MARGIN = 1, function(x){predict.class(x, fit.kmeans$centers)} )
    
    if(length(which(train.cluster == 1)) > 2 && length(which(train.cluster == 2)) > 2 &&
       length(which(test.cluster == 1)) > 2 && length(which(test.cluster == 2)) > 2){
      
      train.x1 = train.x[which(train.cluster == 1),]
      train.x2 = train.x[which(train.cluster == 2),]
      test.x1 = test.x[which(test.cluster == 1),]
      test.x2 = test.x[which(test.cluster == 2),]
      
      parent.node = c(parent.node, rep(parent.index, 2))
      which.child = c(which.child, 1, 2)
      ntrain = c(ntrain, nrow(train.x1), nrow(train.x2))
      ntest = c(ntest, nrow(test.x1), nrow(test.x2))
      all.centers = rbind(all.centers,fit.kmeans$centers)
      all.WSS = c(all.WSS, fit.kmeans$withinss)
      
      children.list[[parent.index]] = c(children.index, children.index + 1)
      test.reject.list[[parent.index]] = list(reject = F, fit = NULL)
      
      train.list[[children.index]] = train.x1
      test.list[[children.index]] = test.x1
      model.fit[[children.index]] = fit.kmeans
      children.list[[children.index]] = c(0,0)
      test.reject.list[[children.index]] = list(reject = F, fit = NULL)
      children.index = children.index + 1
      
      train.list[[children.index]] = train.x2
      test.list[[children.index]] = test.x2
      model.fit[[children.index]] = fit.kmeans
      children.list[[children.index]] = c(0,0)
      test.reject.list[[children.index]] = list(reject = F, fit = NULL)
      children.index = children.index + 1
    }
    
    parent.index = parent.index + 1
  }
  
  parent.index = children.index - 1
  leaf.nodes = c((parent.node[parent.index]+1):(parent.index))
  parent.index = min(leaf.nodes) - 1
  
  while(parent.index > 0){
    
    if(children.list[[parent.index]][1] != 0){
      train.x = train.list[[parent.index]]
      test.x = test.list[[parent.index]]
      
      which.children = c(which(leaf.nodes == children.list[[parent.index]][1]),
                         which(leaf.nodes == children.list[[parent.index]][2]))
      leaf.nodes.new = c(leaf.nodes[-which.children], parent.index)
      centers = all.centers[leaf.nodes.new,]
      WSS = all.WSS[leaf.nodes.new]
      which.leaf = which(leaf.nodes.new == parent.index)
      if(length(leaf.nodes.new)==1){
        centers = t(as.matrix(centers))
      }
      fit = one.step.recursive.clustering(which.leaf, centers, WSS, components = 2, 
                                          train.x, test.x, truncation)
      reject = (fit$p.value < (alpha/100))
      test.reject.list[[parent.index]] = list(reject = reject, fit = fit)
      if(reject == F){
        leaf.nodes = leaf.nodes.new
      }
      
    }
    parent.index = parent.index - 1
  }
  return(list(model.fit = model.fit, leaf.nodes = leaf.nodes, train.cluster = train.list,
              test.cluster = test.list, test.reject.list = test.reject.list,
              parents = parent.node, all.centers = all.centers, all.WSS = all.WSS,
              which.child = which.child, children.list = children.list,
              ntrain = ntrain, ntest = ntest))
}

BottomupclusteringMarron_SigClust <- function(data, alpha = 0.05){
  
  
  # Defining the outputs
  model.fit = list()
  data.list = list()
  test.reject.list = list()
  children.list = list()
  parent.node = c(0)
  leaf.nodes = c(1)
  which.child = c(1)
  parent.index = 1
  children.index = 2
  n = nrow(data)
  a = floor(n/2)
  
  data.list[[parent.index]] = data
  model.fit[[parent.index]] = kmeans(data, centers = 1)
  
  while(parent.index < children.index && children.index < 10
        && nrow(data.list[[parent.index]])!=0){
    
    
    data.x = data.list[[parent.index]]
    fit.kmeans = kmeans(data.x, centers = 2)
    cluster = fit.kmeans$cluster
    
    if(length(which(cluster == 1)) > 2 && length(which(cluster == 2)) > 2){
      
      data.x1 = data.x[which(cluster == 1),]
      data.x2 = data.x[which(cluster == 2),]
      
      parent.node = c(parent.node, rep(parent.index, 2))
      which.child = c(which.child, 1, 2)
      
      children.list[[parent.index]] = c(children.index, children.index + 1)
      test.reject.list[[parent.index]] = list(reject = F, fit = NULL)
      
      data.list[[children.index]] = data.x1
      model.fit[[children.index]] = fit.kmeans
      children.list[[children.index]] = c(0,0)
      test.reject.list[[children.index]] = list(reject = F, fit = NULL)
      children.index = children.index + 1
      
      data.list[[children.index]] = data.x2
      model.fit[[children.index]] = fit.kmeans
      children.list[[children.index]] = c(0,0)
      test.reject.list[[children.index]] = list(reject = F, fit = NULL)
      children.index = children.index + 1
    }
    
    parent.index = parent.index + 1
  }
  
  parent.index = children.index - 1
  leaf.nodes = c((parent.node[parent.index]+1):(parent.index))
  parent.index = min(leaf.nodes) - 1
  
  while(parent.index > 0){
    
    if(children.list[[parent.index]][1] != 0){
      data.x = data.list[[parent.index]]
      
      which.children = c(which(leaf.nodes == children.list[[parent.index]][1]),
                         which(leaf.nodes == children.list[[parent.index]][2]))
      leaf.nodes.new = c(leaf.nodes[-which.children], parent.index)
      #which.leaf = which(leaf.nodes.new == parent.index)
      error.trigger = 0
      fit = tryCatch(sigclust(data.x, nsim = 1000),
                     error = function(err) {
                       
                       # error handler picks up where error was generated
                       print(paste("MY_ERROR:  ",err))
                       return(NA)
                     })
      if(is.na(fit)){return(list(error.trigger = 1))}
      alpha.new = alpha/(2^(2*(floor(log2(parent.index)))+1))
      reject = (slot(fit, "pval") < (alpha/100))
      test.reject.list[[parent.index]] = list(reject = reject, fit = fit)
      if(reject == F){
        leaf.nodes = leaf.nodes.new
      }
      
    }
    parent.index = parent.index - 1
  }
  return(list(model.fit = model.fit, leaf.nodes = leaf.nodes, data.cluster = data.list,
              test.reject.list = test.reject.list, parents = parent.node, 
              error.trigger = error.trigger,which.child = which.child, 
              children.list = children.list))
}

