Source Files:

RIFT:

Unconditional_Simple_Test.R - The main RIFT test code

    Important functions:
    - Ri.compute - Computes the Ri as proposed in the paper
    - KL.Test1.mixture - Performs RIFT (takes input Ri, if truncated test, then the truncation ratio, and alpha the size of the test).
    - KL.Test2.mixture.median - Performs M-RIFT (takes input Ri, if truncated test, then the truncation ratio, and alpha the size of the test).
    - Simple.Test1 - RIFT or M-RIFT the basic test for detecting one versus two clusters. (Takes input the training data, test data, alpha, whether to use median, if truncated then the truncation ratio.)


main_topdown_hierarchical.R - Top-down hierarchical

    Important functions:
    - Topdownclustering - Top-down H-RIFT (Input data, alpha)


main_bottomup_hierarchical.R - Bottom-up hierarchical

    Important functions:
    - Bottomupclustering - Bottom-up H-RIFT (Input data, alpha)


Model.selection.approach - S-RIFT sequential version of RIFT

    Important functions:
    - Model.selection.approach - S-RIFT (Input training data, test data, alpha, modelNames to pass on to densityMclust, diagonal specifying whether just diagonal variance structures should be fit or not.)

--------------------------------------------------------------------------------------

SigClust

main_topdown_Marron.R - Top-down and Bottom-up truncated and non-truncated versions of SigClust

    Important functions:
    - TopdownclusteringMarron_SigClust - Top-down truncated or untruncated hierarchical SigClust
    - BottomupclusteringMarron_SigClust - Bottom-up truncated or untruncated hierarchical SigClust
    - TopdownclusteringMarron - Top-down hierarchical using sigclust function from sigclust package
    - BottomupclusteringMarron - Bottom-up hierarchical using sigclust function from sigclust package
    
--------------------------------------------------------------------------------------

Mardia's Kurtosis Test

Mardia_Kurtosis.R - Mardia's Kurtosis Test

   Important functions:
   - asym.Kurtosis.test - Performs the test (Input data, alpha)

--------------------------------------------------------------------------------------

Zhou's Nearest Neighbor Test

Zhou_NN_Test.R - Zhou's Nearest Neighbor Test

   Important functions:
   - asym.NN.test - Performs the normal test (Input data, fitted Gaussian, alpha)
   - KS.NN.test - The KS version of the test (Input data, fitted Gaussian, alpha)

--------------------------------------------------------------------------------------

Experiments:

1. Comparing_Test.R - Section 6.2.0 Experiments
2. SigClustExperiments.R - Section 6.2 remaining experiments. 
       - SimulComparision.R - supporting source file
3. main_Hierarchical_experiments_examples.R - Section 6.3
       - Hierarchical_experiments_examples.R - supporting source file
4. main.model.selection.approach - Section 6.4
5. Gene_expression_main_v2.R - Section 7
