rm(list=ls())
library(mixtools)
library(mclust)
setwd("~/Documents/Clustering research")
source("main_bottomup_hierarchical.R")
source("main_topdown_Marron.R")
source("SimulComparision.R")


Finding.Power.tests <- function(n, mu, d, sds = rep(1,d), alpha = 0.05, K = 100){
  
  reject_simple = rep(1,K)
  reject_simple_median = rep(1,K)
  reject_Mardia = rep(1,K)
  reject_NN = rep(1,K)
  reject_NN_KS = rep(1,K)
  reject_Marron = rep(1,K)
  #reject_MTest = rep(1,K)
  
  for(i in 1:K){
    
    #data = mvrnorm(n[j],mu=c(0,0),Sigma=diag(1,2))
    which.comp = sample(1:2,prob=c(0.5,0.5),size=n,replace=TRUE)
    mus = rbind(-mu,mu)
    data <- t(sapply(which.comp, function(i){mvrnorm(n=1,mu=mus[i,],Sigma=diag(sds))}))
    train.x = data[1:(n/2),]
    test.x = data[((n/2)+1):n,]
    model1 = densityMclust(data = train.x, G = 1, model = "XXX")
    model2 = densityMclust(data = train.x, G = 2, model = "EEE")
    Ri = Ri.compute(test.x, model1, model2)
    log.truncation.ratio = 0
    simple = KL.Test1.mixture(Ri, log.truncation.ratio, alpha)
    simple_median = KL.Test2.mixture.median(Ri, log.truncation.ratio, alpha)
    Mardia = asym.Kurtosis.test(data, alpha)
    NN = asym.NN.test(test.x, model1, alpha = 0.05)
    NN_KS = KS.NN.test(test.x, model1, alpha = 0.05)
    fit.kmeans = kmeans(train.x, centers = 1)
    centers = fit.kmeans$centers
    WSS = fit.kmeans$withinss
    Marron = one.step.recursive.clustering(1, centers, WSS, components = 2, train.x, test.x)
    
    if(simple$reject == FALSE){
      reject_simple[i] = 0
    }
    if(simple_median$reject == FALSE){
      reject_simple_median[i] = 0
    }
    if(Mardia$reject == FALSE){
      reject_Mardia[i] = 0
    }
    if(NN$reject == FALSE){
      reject_NN[i] = 0
    }
    if(NN_KS$reject == FALSE){
      reject_NN_KS[i] = 0
    }
    if(Marron$p.value > alpha){
      reject_Marron[i] = 0
    }
    #print(i)
  }
  return(list(reject_simple = reject_simple, reject_simple_median = reject_simple_median, 
              reject_Mardia = reject_Mardia, reject_NN = reject_NN, 
              reject_NN_KS = reject_NN_KS, reject_Marron = reject_Marron))
}

# Comparing Tests with respect to varying n

K = 100
#n = seq(from = 100, to = 1000, by = 50)
n = c(100, 200, 300, 400, 500, 1000, 1500, 2000, 5000, 10000)
Power_simple = rep(0, length(n))
Power_simple_median = rep(0, length(n))
Power_Mardia = rep(0, length(n))
Power_NN = rep(0, length(n))
Power_NN_KS = rep(0, length(n))
Power_Marron = rep(0, length(n))
mu = c(2,0)
sds = rep(1,2)
d = length(mu)

for(j in 1: length(n)){
  
Power.tests = Finding.Power.tests(n[j], mu, d, sds, alpha = 0.05, K)
Power_simple[j] = mean(Power.tests$reject_simple)
Power_simple_median[j] = mean(Power.tests$reject_simple_median)
Power_Mardia[j] = mean(Power.tests$reject_Mardia)
Power_NN[j] = mean(Power.tests$reject_NN)
Power_NN_KS[j] = mean(Power.tests$reject_NN_KS)
Power_Marron[j] = mean(Power.tests$reject_Marron)
print(j)
}

Power = data.frame(n = n, Simple = Power_simple, Simple_median = Power_simple_median,
                   Mardia = Power_Mardia, NN = Power_NN, NN_KS = Power_NN_KS, Marron = Power_Marron)
write.csv(Power, "Compare_logn.csv")
Power = read.csv("Compare_logn.csv")

Power = data.frame(n = rep(Power$n, 6),
              Power_act = c(Power$Simple, Power$Simple_median, Power$Mardia, Power$NN, Power$NN_KS, Power$Marron),
              Method = c(rep("RIFT",length(Power$n)), rep("M-RIFT",length(Power$n)),
                         rep("Mardia's Kurtosis Test",length(Power$n)),
                         rep("Zhou's NN Test",length(Power$n)),
                         rep("Zhou's NN Test with KS",length(Power$n)),
                         rep("SigClust",length(Power$n))))

plot1 <- ggplot(Power, aes(x = log(Power$n), y = Power_act, lty = Method, color = Method)) + 
  geom_line(size = 0.75) +
  ggtitle("Comparing Clustering Techniques with n varying")+
  xlab("Log n") + ylab("Power")+
  theme_bw() +
  #eliminates background, gridlines, and chart border
  theme(
    panel.grid.major = element_blank()
    ,panel.grid.minor = element_blank()
    ,panel.border = element_rect(colour="black",  linetype = 1)
  ) 

#plot1 <- ggplot(Power, aes(x = log(Power$n))) + 
#  ggtitle("Comparing Clustering Techniques with n varying")+
#  xlab("Log n") + ylab("Power")+
#  geom_line(aes(y = Power$Simple, colour= "RiFT",lty = "RiFT")) + 
#  geom_line(aes(y = Simple_median, colour = "RiFT with Median", lty = "RiFT with Median")) +
#  geom_line(aes(y = Mardia, colour = "Mardia's Kurtosis Test", lty = "Mardia's Kurtosis Test")) +
#  geom_line(aes(y = NN, colour = "Zhou's NN Test", lty = "Zhou's NN Test")) +
#  geom_line(aes(y = NN_KS, colour = "Zhou's NN Test with KS", lty = "Zhou's NN Test with KS")) +
#  geom_line(aes(y = Marron, colour = "SigClust", lty = "SigClust"))
  
pdf("CompareClusterN0322_allmethods.pdf", width = 6, height = 4)
plot1
dev.off()

pdf("CompareClusterNv3_allmethods.pdf", width = 6, height = 4)
plot1
dev.off()

# Comparing Tests with respect to varying distance between the two means

K = 100
n = 1000
a = seq(from = 0.1, to = 3, by = 0.1)
Power_simple = rep(0, length(a))
Power_simple_median = rep(0, length(a))
Power_Mardia = rep(0, length(a))
Power_NN = rep(0, length(a))
Power_NN_KS = rep(0, length(a))
Power_Marron = rep(0, length(a))
sds = rep(1,2)

for(j in 1: length(a)){
  
  n = 1000
  mu = c(a[j],0)
  d = length(mu)
  Power.tests = Finding.Power.tests(n, mu, d, sds, alpha = 0.05, K)
  Power_simple[j] = mean(Power.tests$reject_simple)
  Power_simple_median[j] = mean(Power.tests$reject_simple_median)
  Power_Mardia[j] = mean(Power.tests$reject_Mardia)
  Power_NN[j] = mean(Power.tests$reject_NN)
  Power_NN_KS[j] = mean(Power.tests$reject_NN_KS)
  Power_Marron[j] = mean(Power.tests$reject_Marron)
  print(j)
}

Power = data.frame(a = 2*a, Simple = Power_simple, Simple_median = Power_simple_median,
                   Mardia = Power_Mardia, NN = Power_NN, NN_KS = Power_NN_KS, Marron = Power_Marron)
write.csv(Power, "Compare_a.csv")
Power = read.csv("Compare_a.csv")

Power = data.frame(a = rep(Power$a, 6),
                   Power_act = c(Power$Simple, Power$Simple_median, Power$Mardia, Power$NN, Power$NN_KS, Power$Marron),
                   Method = c(rep("RIFT",length(Power$a)), rep("M-RIFT",length(Power$a)),
                              rep("Mardia's Kurtosis Test",length(Power$a)),
                              rep("Zhou's NN Test",length(Power$a)),
                              rep("Zhou's NN Test with KS",length(Power$a)),
                              rep("SigClust",length(Power$a))))

plot2 <- ggplot(Power, aes(x = a, y = Power_act, lty = Method, color = Method)) + 
  geom_line(size = 0.75) +
  ggtitle("Clustering Techniques with distance between means varying")+
  xlab("Distance between the clusters") + ylab("Power")+
  theme_bw() +
  #eliminates background, gridlines, and chart border
  theme(
    panel.grid.major = element_blank()
    ,panel.grid.minor = element_blank()
    ,panel.border = element_rect(colour="black",  linetype = 1)
  ) 


#plot2 <- ggplot(Power, aes(x = a)) + 
#  ggtitle("Clustering Techniques with distance between means varying")+
#  xlab("Distance between the clusters") + ylab("Power")+
#  geom_line(aes(y = Simple, colour = "Simple Test")) + 
#  geom_line(aes(y = Simple_median, colour = "Simple Test with Median")) +
#  geom_line(aes(y = Mardia, colour = "Mardia's Kurtosis Test")) +
#  geom_line(aes(y = NN, colour = "Zhou's NN Test")) +
#  geom_line(aes(y = NN_KS, colour = "Zhou's NN Test with KS")) +
#  geom_line(aes(y = Marron, colour = "LHNM Test"))

pdf("CompareClustermeansA0322_all.pdf", width = 6, height = 4)
plot2
dev.off()

pdf("CompareClustermeansv3_all.pdf", width = 6, height = 4)
plot2
dev.off()


# Comparing Tests with varying dimension

K = 20
n = 1000
d = c(2,3,4,5,10,20, 50,100, 500, 1000)
Power_simple = rep(0, length(d))
Power_simple_median = rep(0, length(d))
Power_Mardia = rep(0, length(d))
Power_NN = rep(0, length(d))
Power_NN_KS = rep(0, length(d))
Power_Marron = rep(0, length(d))
pvalue_simple = rep(1,length(d))
pvalue_simple_median = rep(1,length(d))
pvalue_Mardia = rep(1,length(d))
pvalue_NN = rep(1,length(d))
pvalue_NN_KS = rep(1,length(d))
pvalue_Marron = rep(1,length(d))

for(j in 1: length(d)){
  
  sds = rep(1, d[j])
  sds[2] = 1
  mu = c(10,rep(0,(d[j] - 1)))
  Power.tests = Finding.Power.tests(n, mu, d[j], sds, alpha = 0.05, K)
  Power_simple[j] = mean(Power.tests$reject_simple)
  Power_simple_median[j] = mean(Power.tests$reject_simple_median)
  Power_Mardia[j] = mean(Power.tests$reject_Mardia)
  Power_NN[j] = mean(Power.tests$reject_NN)
  Power_NN_KS[j] = mean(Power.tests$reject_NN_KS)
  Power_Marron[j] = mean(Power.tests$reject_Marron)
  pvalue_simple[j] = mean(Power.tests$pvalue_simple)
  pvalue_simple_median[j] = mean(Power.tests$pvalue_simple_median)
  pvalue_Mardia[j] = mean(Power.tests$pvalue_Mardia)
  pvalue_NN[j] = mean(Power.tests$pvalue_NN)
  pvalue_NN_KS[j] = mean(Power.tests$pvalue_NN_KS)
  pvalue_Marron[j] = mean(Power.tests$pvalue_Marron)
  print(j)
}

Power = data.frame(dim = d, Simple = Power_simple, Simple_median = Power_simple_median,
                   Mardia = Power_Mardia, NN = Power_NN, NN_KS = Power_NN_KS, Marron = Power_Marron)
plot3 <- ggplot(Power[1:7,], aes(x = dim)) + 
  ggtitle("Clustering Techniques with dimension varying")+
  xlab("Dimension") + ylab("Power")+
  geom_line(aes(y = Simple, colour = "Simple Test")) + 
  geom_line(aes(y = Simple_median, colour = "Simple Test with Median")) +
  geom_line(aes(y = Mardia, colour = "Mardia's Kurtosis Test")) +
  geom_line(aes(y = NN, colour = "Zhou's NN Test")) +
  geom_line(aes(y = NN_KS, colour = "Zhou's NN Test with KS")) +
  geom_line(aes(y = Marron, colour = "LHNM Test"))

pdf("CompareClusterDimns1212.pdf", width = 8, height = 5)
plot3
dev.off()
