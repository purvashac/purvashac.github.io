rm(list=ls())
library(mixtools)
library(mclust)
library(TCGA2STAT)
library(dplyr)
library(Rmixmod)
setwd("~/Documents/Clustering research")
source("main_bottomup_hierarchical_v2.R")
source("main_topdown_hierarchical_v2.R")
source("main_topdown_Marron.R")
source("SimulComparision.R")
source("Model.selection.approach.R")

std.normalize <- function(x, mu, sigma){
  return((x - mu)/sigma)
}

# Ignore all this

exp.ov <- getTCGA(disease="GBM", data.type="mRNA_Array", type="G450")
u133a.ov <- getTCGA(disease="GBM", data.type="mRNA_Array", type="U133")
huex.ov <- getTCGA(disease="GBM", data.type="mRNA_Array", type="Huex")
# step 1: merge G450 and U133
comb1.ov <- OMICSBind(dat1 = exp.ov$dat, dat2 = u133a.ov$dat)
# step 2: further concatenate the Huex data to the merged data-object
comb2.ov <- OMICSBind(dat1 = comb1.ov$merged.data, dat2 = huex.ov$dat)
# Making the observations as rows
gene.merged.data.ov = t(comb2.ov$merged.data)
# Remove observations with NA values
gene.merged.data.ov.no.na = na.omit(gene.merged.data.ov)
# Remove genes with low sd/mean
mean.genes = colMeans(gene.merged.data.ov.no.na)
sd.genes = apply(gene.merged.data.ov.no.na, MARGIN = 2, sd)
idx = which(sd.genes/mean.genes > 2.738) # makes it 2727 genes
data = gene.merged.data.ov.no.na[,idx]


n = nrow(data)
d = ncol(data)

# Ignore the above

HNSC.RNAseq2 <- getTCGA(disease="HNSC", data.type="RNASeq2")
LUSC.RNAseq2 <- getTCGA(disease="LUSC", data.type="RNASeq2")
LUAD.RNAseq2 <- getTCGA(disease="LUAD", data.type="RNASeq2")

data.RNAseq2 = cbind(HNSC.RNAseq2$dat[,1:100], LUSC.RNAseq2$dat[,1:100], 
                     LUAD.RNAseq2$dat[,1:100])
# Making the observations as rows
data.RNAseq2 = t(data.RNAseq2)
# Remove observations with NA values
data.RNAseq2 = na.omit(data.RNAseq2)

#Calculate MAD about median of the genes
Median.genes = apply(data.RNAseq2, 2, mad)
Median.genes.order = order(Median.genes, decreasing = T)

# Considering top 500 genes:

data.RNAseq2.500 = data.RNAseq2[,Median.genes.order[1:500]]

# Log transform the data:
min.genes = apply(data.RNAseq2.500, 2, min)
for(i in which(min.genes == 0)){
  min.genes[i] = min(data.RNAseq2.500[-which(data.RNAseq2.500[,i] == 0),i])
}
for(j in 1:ncol(data.RNAseq2.500)){
  data.RNAseq2.500[which(data.RNAseq2.500[,j] == 0),j] = min.genes[j]
}
data.RNAseq2.500 = log(data.RNAseq2.500)
data.RNAseq2.500.notrandom = data.RNAseq2.500

# Log transform the data 2:
min.genes = apply(data.RNAseq2.500, 2, min)
for(i in which(min.genes == 0)){
  min.genes[i] = min(data.RNAseq2.500[-which(data.RNAseq2.500[,i] == 0),i])
}
min.genes = min(min.genes)
for(j in 1:ncol(data.RNAseq2.500)){
  data.RNAseq2.500[which(data.RNAseq2.500[,j] == 0),j] = min.genes
}
data.RNAseq2.500 = log(data.RNAseq2.500)
data.RNAseq2.500.notrandom = data.RNAseq2.500

# Standard normalize
#mu = colMeans(data.RNAseq2.500)
#sigma = apply(data.RNAseq2.500, 2, sd)
#data.RNAseq2.500 = apply(data.RNAseq2.500, 1, std.normalize, mu = mu,
#                            sigma = sigma)

# Randomizing rows
set.seed(23)
data.RNAseq2.500 = data.RNAseq2.500[sample.int(nrow(data.RNAseq2.500)),]

# AIC - 12, BIC - 8

AIC = rep(0,12)
BIC = rep(0,12)
for(i in 1:12){
  
  Model_test = Mclust(data.RNAseq2.500, G = i)
  BIC[i] = log(300)*Model_test$df - 2*Model_test$loglik
  AIC[i] = 2*Model_test$df - 2*Model_test$loglik
  
}

which.min(AIC)
which.min(BIC)

#BIC

mclustBIC(data.RNAseq2.500)
BIC_model = Mclust(data.RNAseq2.500)
BIC_model$G


# Running the different top down and bottom up methods

alpha = 0.05
Hierarchical_cluster_top = Topdownclustering(data.RNAseq2.500, alpha)
error.trigger1 = Hierarchical_cluster_top$error.trigger
#Hierarchical_cluster_Marron_top = TopdownclusteringMarron(data.RNAseq2.500, alpha, truncation = T)
Hierarchical_cluster_Marron_SigClust_top = TopdownclusteringMarron_SigClust(data.RNAseq2.500, alpha)
error.trigger2 = Hierarchical_cluster_Marron_SigClust_top$error.trigger

if(error.trigger1 == 0){
  
  x = output_tree(Hierarchical_cluster_top$test.reject.list,
                  Hierarchical_cluster_top$parents, method = "simple")
  y = t(sapply(x, function(i){return(Hierarchical_cluster_top$children.list[[i]])}))
  Simple_topdown = length(which(!y %in% x))
  
  x = output_tree(Hierarchical_cluster_top$test.reject.list,
                  Hierarchical_cluster_top$parents, method = "simple_median")
  y = t(sapply(x, function(i){return(Hierarchical_cluster_top$children.list[[i]])}))
  Simple_Median_topdown = length(which(!y %in% x))
  
  #x = output_tree(Hierarchical_cluster_top$test.reject.list,
  #                Hierarchical_cluster_top$parents, method = "Mardia")
  #y = t(sapply(x, function(i){return(Hierarchical_cluster_top$children.list[[i]])}))
  #Mardia_topdown = length(which(!y %in% x))
}

#Marron_topdown = length( Hierarchical_cluster_Marron_top$leaf.nodes)

if(error.trigger2 == 0){
  Marron_SigClust_topdown = length(Hierarchical_cluster_Marron_SigClust_top$leaf.nodes)
}

# Bottomup algorithms

alpha = 0.05  
Hierarchical_cluster = Bottomupclustering(data.RNAseq2.500, alpha)
error.trigger1 = Hierarchical_cluster$error.trigger
#Hierarchical_cluster_Marron = BottomupclusteringMarron(data.RNAseq2.500, alpha, truncation = T)
Hierarchical_cluster_Marron_SigClust = BottomupclusteringMarron_SigClust(data.RNAseq2.500, alpha)
error.trigger2 = Hierarchical_cluster_Marron_SigClust$error.trigger

if(error.trigger1 == 0){
  
  x = output_tree(Hierarchical_cluster$test.reject.list,
                  Hierarchical_cluster$parents, method = "simple")
  y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
  Simple_bottomup = length(which(!y %in% x))
  
  x = output_tree(Hierarchical_cluster$test.reject.list,
                  Hierarchical_cluster$parents, method = "simple_median")
  y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
  Simple_Median_bottomup = length(which(!y %in% x))
  
  #x = output_tree(Hierarchical_cluster$test.reject.list,
  #                Hierarchical_cluster$parents, method = "Mardia")
  #y = t(sapply(x, function(i){return(Hierarchical_cluster$children.list[[i]])}))
  #Mardia_bottomup = length(which(!y %in% x))
}

#Marron_bottomup = length( Hierarchical_cluster_Marron$leaf.nodes)

if(error.trigger2 == 0){
  Marron_SigClust_bottomup = length(Hierarchical_cluster_Marron_SigClust$leaf.nodes)
}

#Model selection approach

n = nrow(data.RNAseq2.500)
train.x = data.RNAseq2.500[1:floor(n/2),]
test.x = data.RNAseq2.500[(floor(n/2)+1):n,]
Cluster_number = Model.selection.approach(train.x, test.x, alpha = 0.01)  

Simple_seq = Cluster_number$simple
AIC = Cluster_number$Min_AIC
BIC = Cluster_number$Min_BIC

# Results

data.RNAseq2.500 = data.RNAseq2.500.notrandom

# RIFT

Hierarchical_cluster_top$test.reject.list[[1]]
Hierarchical_cluster_top$test.reject.list[[2]]
Hierarchical_cluster_top$test.reject.list[[3]]
first.cluster = which.cluster(data.RNAseq2.500, Hierarchical_cluster_top$model.mixture[[1]],
                              diagonal = T)
which.in.second.cluster = which(first.cluster == 2)
which.in.first.cluster = which(first.cluster == 1)
second.cluster = rep(0, length(first.cluster))
second.cluster[which.in.second.cluster] = 3
second.cluster[which.in.first.cluster] = which.cluster(data.RNAseq2.500[which.in.first.cluster,], 
                                                       Hierarchical_cluster_top$model.mixture[[2]], diagonal = T)
second.cluster[which.in.second.cluster] = 2 + which.cluster(data.RNAseq2.500[which.in.second.cluster,], 
                                                            Hierarchical_cluster_top$model.mixture[[3]], diagonal = T)

table(second.cluster[1:100])
table(second.cluster[101:200])
table(second.cluster[201:300])
# 2 -> HNSC, 1 -> LUSC, 3 -> LUAD

# Marron
first.cluster = rep(0, nrow(data.RNAseq2.500))
first.cluster[which(rownames(data.RNAseq2.500) %in% 
                      rownames(Hierarchical_cluster_Marron_SigClust_top$data.cluster[[2]]))] = 1
first.cluster[which(rownames(data.RNAseq2.500) %in% 
                      rownames(Hierarchical_cluster_Marron_SigClust_top$data.cluster[[3]]))] = 2

second.cluster = first.cluster
second.cluster[which(rownames(data.RNAseq2.500) %in% 
                       rownames(Hierarchical_cluster_Marron_SigClust_top$data.cluster[[6]]))] = 6
second.cluster[which(rownames(data.RNAseq2.500) %in% 
                       rownames(Hierarchical_cluster_Marron_SigClust_top$data.cluster[[7]]))] = 7

#Hierarchical_cluster_Marron$test.reject.list[[1]]
#Hierarchical_cluster_Marron$test.reject.list[[2]]
#Hierarchical_cluster_Marron$test.reject.list[[3]]
#first.cluster = apply(data.RNAseq2.500, MARGIN = 1, function(x){
#  predict.class(x,Hierarchical_cluster_Marron$all.centers
#                [Hierarchical_cluster_Marron$leaf.nodes,])} )
#Hierarchical_cluster_Marron$leaf.nodes
#Hierarchical_cluster_Marron$children.list
table(second.cluster[1:100])
table(second.cluster[101:200])
table(second.cluster[201:300])

# Model selection approach

first.cluster = which.cluster(data.RNAseq2.500.notrandom, model[[3]])
table(first.cluster[1:100])
table(first.cluster[101:200])
table(first.cluster[201:300])



