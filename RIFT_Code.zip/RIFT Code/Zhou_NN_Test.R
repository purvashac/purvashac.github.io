library(MASS)
library(ggplot2)
library(grid)
library(gridExtra)

closest.dist <- function(x){
  return(min(x[which(x > 0)]))
}

Test.Statistic.NN <- function(data, model1){
  
  d = ncol(data)
  n = nrow(data)
  #mu = model1$parameters$mean
  #Sn = model1$parameters$variance$Sigma
  #Sninve = solve(Sn)
  data1 = t(sapply(c(1:n), function(i){return(data[i,] - t(mu))}))
  distance = as.matrix(dist(data1, method = "euclidean"))
  R = apply(distance, 1, FUN=closest.dist)
  scaling = sapply(c(1:n), function(i){
    return( logdensitynormal(data[i,],t(model1$parameters$mean), 
                             model1$parameters$variance$sigma[,,1]))
  })
  
  #lognfX = log(n) - (0.5*log(det(2*pi*Sn))) - 0.5*scaling
  lognfX = log(n) + scaling
  lognD = lognfX + (d/2)*log(pi) + d*log(R) - lgamma((d/2)+1)
  vectorstat = exp(-exp(lognD))
  Teststat = (1/sqrt(n))*sum(vectorstat-0.5)
  sd = sd(vectorstat)
  #Teststat = (1/sqrt(n))*sum(exp(lognD)-1)
  #sd = sd(exp(lognD))
  Teststat = Teststat/sd
  return(list(Teststatistic = Teststat, vectorstat = vectorstat))
}

asym.NN.test <- function(data, model1, alpha = 0.05){
  
  Teststat = Test.Statistic.NN(data,  model1)$Teststatistic
  reject = (abs(Teststat) > qnorm(1 - (alpha/2)))
  pvalue = 2*pnorm(-abs(Teststat))
  return(list(reject = reject, pvalue = pvalue))
}

KS.NN.test <- function(data, model1, alpha = 0.05){
  
  Test = ks.test(Test.Statistic.NN(data, model1)$vectorstat, "punif",alternative = "two.sided")
  pvalue = Test$p.value
  reject = (pvalue < alpha)
  return(list(reject = reject, pvalue = pvalue))
}

# Example
#data = mvrnorm(n=1000,mu=c(0,0),Sigma=diag(1,2))
#asym.NN.test(data)
