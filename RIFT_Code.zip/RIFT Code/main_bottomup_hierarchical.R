library(MASS)
library(ggplot2)
library(grid)
library(gridExtra)
library(mixtools)
library(mclust)
library(data.tree)
library(mixtools)
#setwd("~/Documents/Clustering research")
#source("Unconditional_Simple_Test.R")
#source("Mardia_Kurtosis.R")
#source("Zhou_NN_Test.R")
#source("MTest_v1.R")
source("main_topdown_hierarchical.R")

Bottomupclustering <- function(data, alpha = 0.05){
  
  
  # Defining the outputs
  model.single = list()
  model.mixture = list()
  train.list = list()
  test.list = list()
  test.reject.list = list()
  children.list = list()
  parent.node = c(0)
  which.child = 0
  parent.index = 1
  children.index = 2
  n = nrow(data)
  a = floor(4*n/5)
  
  train.x = data[1:a,]
  test.x = data[(a+1):n,]
  train.list[[parent.index]] = train.x
  test.list[[parent.index]] = test.x
  ntrain = c(nrow(train.x))
  ntest = c(nrow(test.x))
  
  while(parent.index < children.index && children.index < 20
        && nrow(train.list[[parent.index]])!=0
        && nrow(test.list[[parent.index]])!=0){
    
    
    train.x = train.list[[parent.index]]
    test.x = test.list[[parent.index]]
    model1 = densityMclust(data = train.x, G = 1)
    error.trigger = 0
    #if(norm(mus[1,]-mus[2,], type = "2") == 0){
    #  model2 = fitting.mixture.model(data = train.x, G = 2, modelNames = "EEI",
    #                                starting.means = rbind(mus[1,]-rep(0.1,ncol(mus)), 
    #                                                        mus[2,]+rep(0.1,ncol(mus))),
    #                                 starting.variance = diag(rep(1, ncol(data))))
    #}else{
    #  model2 = fitting.mixture.model(data = train.x, G = 2, modelNames = "EEI",
    #                                 starting.means = mus,
    #                                 starting.variance = diag(rep(1, ncol(data))))
    #}
    #model2$modelName = "EEI"
    model2 = tryCatch(densityMclust(data = train.x, G = 2),
                      error = function(err) {
                        
                        # error handler picks up where error was generated
                        print(paste("MY_ERROR:  ",err))
                        return(NA)
                      })
    if(is.na(model2)){return(list(error.trigger = 1))}
    
    diagonal = F
    if(model2$modelName %in% c("EII","VII","EEI","VEI","EVI","VVI")){diagonal = T}
    Split = one.step.split(train.x, test.x, model2, diagonal = diagonal)
    if(Split$ntrain.x1 > 2 && Split$ntest.x1 > 2 &&
       Split$ntrain.x2 > 2 && Split$ntest.x2 > 2){
      
      parent.node = c(parent.node, rep(parent.index, 2))
      which.child = c(which.child, 1, 2)
      ntrain = c(ntrain, Split$ntrain.x1, Split$ntrain.x2)
      ntest = c(ntest, Split$ntest.x1, Split$ntest.x2)
      
      children.list[[parent.index]] = c(children.index, children.index + 1)
      #test.reject.list[[parent.index]] = list(simple = T, simple_median = T, 
      #                                        Mardia = T)
      test.reject.list[[parent.index]] = list(simple = T, simple_median = T)
      
      train.list[[children.index]] = Split$train.x1
      test.list[[children.index]] = Split$test.x1
      children.list[[children.index]] = c(0,0)
      #test.reject.list[[children.index]] = list(simple = F, simple_median = F, 
      #                                        Mardia = F)
      test.reject.list[[parent.index]] = list(simple = T, simple_median = T)
      children.index = children.index + 1
      
      train.list[[children.index]] = Split$train.x2
      test.list[[children.index]] = Split$test.x2
      children.list[[children.index]] = c(0,0)
      #test.reject.list[[children.index]] = list(simple = F, simple_median = F, 
      #                                          Mardia = F)
      test.reject.list[[parent.index]] = list(simple = T, simple_median = T)
      children.index = children.index + 1
    }
    
    model.single[[parent.index]] = model1
    model.mixture[[parent.index]] = model2
    parent.index = parent.index + 1
  }
  
  parent.index = children.index - 1
  
  while(parent.index > 0){
    
    if(children.list[[parent.index]][1] != 0){
      model1 = model.single[[parent.index]]
      model2 = model.mixture[[parent.index]]
      train.x = train.list[[parent.index]]
      test.x = test.list[[parent.index]]
      diagonal = F
      if(model2$modelName %in% c("EII","VII","EEI","VEI","EVI","VVI")){diagonal = T}
      Ri = Ri.compute(test.x, model1, model2, diagonal = diagonal)
    
      if(parent.index == 1){
      
        log.truncation.ratio = 0
        simple.fit = KL.Test1.mixture(Ri, log.truncation.ratio, alpha = (alpha/100))
        simple = simple.fit$reject
        simple_median.fit = KL.Test2.mixture.median(Ri, log.truncation.ratio, alpha = (alpha/100))
        simple_median = simple_median.fit$reject
        #Mardia = asym.Kurtosis.test(test.x, alpha = (alpha/100))$reject
      }else{
      
        rand1 = mvrnorm(n = 1000, mu = model1$parameters$mean[,1],
                        Sigma = model1$parameters$variance$sigma[,,1])
        idx = rbinom(n = 1000, size = 1, prob = model2$parameters$pro[1])
        rand21 = mvrnorm(n = 1000, mu = model2$parameters$mean[,1],
                        Sigma = model2$parameters$variance$sigma[,,1])
        rand22 = mvrnorm(n = 1000, mu = model2$parameters$mean[,2],
                        Sigma = model2$parameters$variance$sigma[,,2])
        rand2 = idx*rand21 + (1 - idx)*rand22
      
        child = parent.index
        idx1 = 1000
        idx2 = 1000
        while(parent.node[child]!= 0){
          parent = parent.node[child]
          model.parent = model.mixture[[parent]]
          k1 = which.child[child]
          if(idx1>1){
            diag1 = F
            if(model.parent$modelName %in% c("EII","VII","EEI","VEI","EVI","VVI")){diag1 = T}
            parent.cluster.indx1 = which.cluster(rand1, model.parent, diagonal = diag1)
            rand1 = rand1[which(parent.cluster.indx1 == k1),]
            idx1 = length(which(parent.cluster.indx1 == k1))
          }
          
          if(idx2 > 1){
            diag2 = F
            if(model.parent$modelName %in% c("EII","VII","EEI","VEI","EVI","VVI")){diag2 = T}
            parent.cluster.indx2 = which.cluster(rand2, model.parent, diagonal = diag2)
            rand2 = rand2[which(parent.cluster.indx2 == k1),]
            idx2 = length(which(parent.cluster.indx2 == k1))
          }
          child = parent
        }
        prop1 = nrow(rand1)
        prop2 = nrow(rand2)
        log.truncation.ratio = log(prop2) - log(prop1)
      
        simple.fit = KL.Test1.mixture(Ri, log.truncation.ratio, alpha = (alpha/100))
        simple = simple.fit$reject
        simple_median.fit = KL.Test2.mixture.median(Ri, log.truncation.ratio, alpha = (alpha/100))
        simple_median = simple_median.fit$reject
        #Mardia = asym.Kurtosis.test(test.x, alpha = (alpha/100))$reject
      }
      
      #test.reject.list[[parent.index]] = list(simple = simple, simple_median = simple_median, 
      #                                        Mardia = Mardia)
      test.reject.list[[parent.index]] = list(simple = simple, simple_median = simple_median, 
                                              simple.fit = simple.fit, 
                                              simple_median.fit = simple_median.fit)
    }
    parent.index = parent.index - 1
  }
  return(list(model.single = model.single, model.mixture = model.mixture, 
              train.cluster = train.list, test.cluster = test.list, 
              test.reject.list = test.reject.list,
              parents = parent.node, error.trigger = 0,
              which.child = which.child,
              children.list = children.list,
              ntrain = ntrain, ntest = ntest))
}

output_tree <- function(test.reject.list, parents, method = "simple"){
  
  print(length(test.reject.list))
  if(length(test.reject.list) == 0){
    print("No splits!!")
    return(NULL)
  }
  if(method == "simple"){
    reject.list = sapply(c(1:length(test.reject.list)),
                         function(i){return(test.reject.list[[i]]$simple)})                      
  }
  if(method == "simple_median"){
    reject.list = sapply(c(1:length(test.reject.list)),
                         function(i){return(test.reject.list[[i]]$simple_median)})                      
  }
  if(method == "Mardia"){
    reject.list = sapply(c(1:length(test.reject.list)),
                         function(i){return(test.reject.list[[i]]$Mardia)})                      
  }
  if(method == "Marron"){
    reject.list = sapply(c(1:length(test.reject.list)),
                         function(i){return(test.reject.list[[i]]$reject)})                      
  }
  if(reject.list[1] == F){
    print("No splits!!")
    return(NULL)
  }else{
    split.parent = which(reject.list == T)
    node.index = 2
    while(node.index <= length(split.parent)){
      
      parent.node = parents[split.parent[node.index]]
      exists = which(split.parent == parent.node)
      if(length(exists) == 0){
        split.parent = split.parent[-node.index]
      }else{
        node.index = node.index + 1
      }
    }
  }
  return(split.parent)
}

graph_trees <- function(fit, method = "simple") {
  
  if(method == "simple"){
    x = output_tree(fit$test.reject.list, fit$parents, "simple")                      
  }
  if(method == "simple_median"){
    x = output_tree(fit$test.reject.list, fit$parents, "simple_median")                      
  }
  if(method == "Mardia"){
    x = output_tree(fit$test.reject.list, fit$parents, "Mardia")                      
  }
  if(method == "Marron"){
    x = output_tree(fit$test.reject.list, fit$parents, "Marron")                      
  }
  if(is.null(x)){
    print("No splits!!")
    return(NULL)
  }else{
    ntrain = fit$ntrain
    ntest = fit$ntest
    y = t(sapply(x, function(i){return(fit$children.list[[i]])}))
    z = c(ntrain[1], ntest[1])
    y = cbind(y, fit$ntrain[y[,1]], fit$ntest[y[,1]])
    y = cbind(y, fit$ntrain[y[,2]], fit$ntest[y[,2]])
    node_data = paste("1"," (",paste(paste("train=",z[1]), paste("test=", z[2]),sep=", "),")")
    tree1 = Node$new(node_data)
    for (i in 1:length(x)) {
      if (!is.na(y[i,1])) {
        first_kid_data = paste(y[i,1]," (",paste(paste("train=",y[i,3]),paste("test=",y[i,4]),sep=", "),")")
        second_kid_data = paste(y[i,2], " (",paste(paste("train=",y[i,5]),paste("test=",y[i,6]),sep=", "),")")
        assign(paste("tree",y[i,1],sep = ""), eval(parse(text = paste("tree",x[i],sep = "")))$AddChild(first_kid_data))
        assign(paste("tree",y[i,2],sep = ""), eval(parse(text = paste("tree",x[i],sep = "")))$AddChild(second_kid_data))
      }
    }
    if(method == "simple"){
      graph = plot(tree1, main = "Tree for Simple")                      
    }
    if(method == "simple_median"){
      graph = plot(tree1, main = "Tree for Simple with Median")                      
    }
    if(method == "Mardia"){
      graph = plot(tree1, main = "Tree for Mardia")                      
    }
    if(method == "Marron"){
      graph = plot(tree1, main = "Tree for Marron")                      
    }
    
    return(graph)
  }
}